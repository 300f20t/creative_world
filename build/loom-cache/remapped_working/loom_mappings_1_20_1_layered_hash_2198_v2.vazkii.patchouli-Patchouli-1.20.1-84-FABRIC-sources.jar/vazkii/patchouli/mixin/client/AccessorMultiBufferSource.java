package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import com.mojang.blaze3d.vertex.BufferBuilder;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;

@Mixin(MultiBufferSource.BufferSource.class)
public interface AccessorMultiBufferSource {
	@Accessor("builder")
	BufferBuilder getFallbackBuffer();

	@Accessor("fixedBuffers")
	Map<RenderType, BufferBuilder> getFixedBuffers();
}
