package net.mcreator.creativeworld.procedures;

import net.minecraft.class_1799;

public class Alargebucketofwater9DopolnitielnaiaInformatsiiaProcedure {
	public static String execute(class_1799 itemstack) {
		return new java.text.DecimalFormat("##.##").format(itemstack.method_7948().method_10574("mb")) + "/10000" + " " + itemstack.method_7948().method_10558("fluid_name");
	}
}
