package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_7923;

public class CrushedtinoreKoghdaNazhataPKMPoBlokuProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == CreativeWorldModItems.CRUSHEDTINORE && entity.method_37908()
				.method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1345, entity)).method_17783() == class_239.class_240.field_1332) {
			if ((world
					.method_8316(new class_2338(
							entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1345, entity)).method_17777().method_10263(),
							entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1345, entity)).method_17777().method_10264(),
							entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1345, entity)).method_17777().method_10260()))
					.method_15759()).method_26204() == class_2246.field_10382) {
				if (!(entity instanceof class_1657 _plr ? _plr.method_31549().field_7477 : false)) {
					if (entity instanceof class_1309 _entity) {
						class_1799 _setstack = new class_1799(CreativeWorldModItems.CRUSHEDTINORE);
						_setstack.method_7939((int) ((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7947() - 1));
						_entity.method_6122(class_1268.field_5808, _setstack);
						if (_entity instanceof class_1657 _player)
							_player.method_31548().method_5431();
					}
				}
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModItems.WASHEDCRUSHEDTINORE);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModItems.TINNUGGET);
					_setstack.method_7939((int) (Math.random() + Math.random() + Math.random()));
					_player.method_31548().method_7394(_setstack);
				}
				if (world instanceof class_1937 _level) {
					if (!_level.method_8608()) {
						_level.method_8396(null, class_2338.method_49637(x, y, z), class_7923.field_41172.method_10223(new class_2960("item.bottle.fill")), class_3419.field_15254, 1, 1);
					} else {
						_level.method_8486(x, y, z, class_7923.field_41172.method_10223(new class_2960("item.bottle.fill")), class_3419.field_15254, 1, 1, false);
					}
				}
			}
		}
	}
}
