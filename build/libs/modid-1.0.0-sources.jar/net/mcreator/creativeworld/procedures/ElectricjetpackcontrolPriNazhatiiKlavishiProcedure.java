package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_243;

public class ElectricjetpackcontrolPriNazhatiiKlavishiProcedure {
	public static void execute(class_1297 entity) {
		if (entity == null)
			return;
		while ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_7909() == CreativeWorldModItems.ELECTRICJETPACK_CHESTPLATE) {
			entity.method_18799(new class_243(0, 0.5, 0));
		}
	}
}
