package net.mcreator.creativeworld.procedures;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;

public class EndlesswatersourceKoghdaNazhataPKMPoBlokuProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		world.method_8652(class_2338.method_49637(x, 1 + y, z), class_2246.field_10382.method_9564(), 3);
		if (entity instanceof class_1309 _entity)
			_entity.method_23667(class_1268.field_5808, true);
	}
}
