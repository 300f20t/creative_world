package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public class DrillKazhdyiTikVRukieProcedure {
	public static boolean execute(class_1297 entity) {
		if (entity == null)
			return false;
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == CreativeWorldModItems.CREATIVEDRILL
				|| (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == CreativeWorldModItems.ADVANCEDDRILL
				|| (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == CreativeWorldModItems.DRILL) {
			return true;
		}
		return false;
	}
}
