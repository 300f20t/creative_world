package net.mcreator.creativeworld.procedures;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_5819;

public class BedrockbreackerPriShchielchkiePravoiKnopkoiMyshiNaBlokieProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity, class_1799 itemstack) {
		if (entity == null)
			return;
		if (class_2246.field_9987 == (world.method_8320(class_2338.method_49637(x, y, z))).method_26204()) {
			if (entity instanceof class_1657 _player) {
				class_1799 _setstack = (new class_1799((world.method_8320(class_2338.method_49637(x, y, z))).method_26204()));
				_setstack.method_7939(1);
				_player.method_31548().method_7394(_setstack);
			}
			world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 40);
		}
		if (class_2246.field_10525 == (world.method_8320(class_2338.method_49637(x, y, z))).method_26204()) {
			if (entity instanceof class_1657 _player) {
				class_1799 _setstack = (new class_1799((world.method_8320(class_2338.method_49637(x, y, z))).method_26204()));
				_setstack.method_7939(1);
				_player.method_31548().method_7394(_setstack);
			}
			world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 40);
		}
		if (class_2246.field_10263 == (world.method_8320(class_2338.method_49637(x, y, z))).method_26204()) {
			if (entity instanceof class_1657 _player) {
				class_1799 _setstack = (new class_1799((world.method_8320(class_2338.method_49637(x, y, z))).method_26204()));
				_setstack.method_7939(1);
				_player.method_31548().method_7394(_setstack);
			}
			world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 40);
		}
		if (class_2246.field_10395 == (world.method_8320(class_2338.method_49637(x, y, z))).method_26204()) {
			if (entity instanceof class_1657 _player) {
				class_1799 _setstack = (new class_1799((world.method_8320(class_2338.method_49637(x, y, z))).method_26204()));
				_setstack.method_7939(1);
				_player.method_31548().method_7394(_setstack);
			}
			world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
			if (entity instanceof class_1657 _player)
				_player.method_7357().method_7906(itemstack.method_7909(), 40);
		}
	}
}
