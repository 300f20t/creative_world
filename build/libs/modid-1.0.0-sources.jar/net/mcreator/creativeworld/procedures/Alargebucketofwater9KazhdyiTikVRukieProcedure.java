package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1799;

public class Alargebucketofwater9KazhdyiTikVRukieProcedure {
	public static void execute(class_1799 itemstack) {
		if (itemstack.method_7909() == CreativeWorldModItems.ALARGEBUCKETOFWATER_9) {
			itemstack.method_7948().method_10549("mb", 10000);
			itemstack.method_7948().method_10582("fluid_full_name", "minecraft:water_bucket");
		} else if (itemstack.method_7909() == CreativeWorldModItems.A_LARGE_BUCKET_OF_FLUID_9) {
			itemstack.method_7948().method_10549("mb", 10000);
			itemstack.method_7948().method_10582("fluid_full_name", "minecraft:lava_bucket");
		}
	}
}
