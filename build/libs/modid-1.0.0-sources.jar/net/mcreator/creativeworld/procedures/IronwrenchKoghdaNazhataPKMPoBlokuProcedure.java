package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_5819;
import net.mcreator.creativeworld.init.CreativeWorldModBlocks;

public class IronwrenchKoghdaNazhataPKMPoBlokuProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		if ((entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909() == CreativeWorldModItems.IRONWRENCH) {
			if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.COALGENERATOR) {
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				{
					class_1799 _ist = (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037);
					if (_ist.method_7970(1, class_5819.method_43047(), null)) {
						_ist.method_7934(1);
						_ist.method_7974(0);
					}
				}
				world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModBlocks.COALGENERATOR);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
			} else if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.CRUSHER) {
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				{
					class_1799 _ist = (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037);
					if (_ist.method_7970(1, class_5819.method_43047(), null)) {
						_ist.method_7934(1);
						_ist.method_7974(0);
					}
				}
				world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModBlocks.CRUSHER);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
			} else if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.FAN) {
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				{
					class_1799 _ist = (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037);
					if (_ist.method_7970(1, class_5819.method_43047(), null)) {
						_ist.method_7934(1);
						_ist.method_7974(0);
					}
				}
				world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModBlocks.FAN);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
			} else if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.BATTERYBLOCK) {
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				{
					class_1799 _ist = (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037);
					if (_ist.method_7970(1, class_5819.method_43047(), null)) {
						_ist.method_7934(1);
						_ist.method_7974(0);
					}
				}
				world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModBlocks.BATTERYBLOCK);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
			} else if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.SOLARPANEL) {
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
				{
					class_1799 _ist = (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037);
					if (_ist.method_7970(1, class_5819.method_43047(), null)) {
						_ist.method_7934(1);
						_ist.method_7974(0);
					}
				}
				world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
				if (entity instanceof class_1657 _player) {
					class_1799 _setstack = new class_1799(CreativeWorldModBlocks.SOLARPANEL);
					_setstack.method_7939(1);
					_player.method_31548().method_7394(_setstack);
				}
			}
		}
	}
}
