package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.mcreator.creativeworld.init.CreativeWorldModBlocks;

public class TapKoghdaNazhataPKMPoBlokuProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity, class_1799 itemstack) {
		if (entity == null)
			return;
		if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.RSINLOGWITHRESIN) {
			world.method_8652(class_2338.method_49637(x, y, z), CreativeWorldModBlocks.RESIN_LOG.method_9564(), 3);
			if (world instanceof class_3218 _level) {
				class_1542 entityToSpawn = new class_1542(_level, (x + (entity.method_23317() - x) / 3), (y + (entity.method_23318() - y) / 3), (z + (entity.method_23321() - z) / 3), new class_1799(CreativeWorldModItems.LATEX));
				entityToSpawn.method_6982(10);
				_level.method_8649(entityToSpawn);
			}
			if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 2)) {
				if (world instanceof class_3218 _level) {
					class_1542 entityToSpawn = new class_1542(_level, (x + (entity.method_23317() - x) / 3), (y + (entity.method_23318() - y) / 3), (z + (entity.method_23321() - z) / 3), new class_1799(CreativeWorldModItems.LATEX));
					entityToSpawn.method_6982(10);
					_level.method_8649(entityToSpawn);
				}
			}
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
			if (entity instanceof class_1309 _entity)
				_entity.method_23667(class_1268.field_5808, true);
		}
	}
}
