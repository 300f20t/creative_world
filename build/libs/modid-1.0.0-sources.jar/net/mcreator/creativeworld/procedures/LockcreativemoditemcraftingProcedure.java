package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModGameRules;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import java.util.Collections;

public class LockcreativemoditemcraftingProcedure {
	public LockcreativemoditemcraftingProcedure() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			execute(handler.method_32311().method_37908(), handler.method_32311());
		});
	}

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		while (true) {
			if (!world.method_8401().method_146().method_8355(CreativeWorldModGameRules.ALLOWCREATIVEMODE)) {
				if (entity instanceof class_3222 _serverPlayer)
					_serverPlayer.field_13995.method_3772().method_8130(new class_2960("xcdfvgbhnj")).ifPresent(_rec -> _serverPlayer.method_7333(Collections.singleton(_rec)));
			}
			if (world.method_8401().method_146().method_8355(CreativeWorldModGameRules.ALLOWCREATIVEMODE)) {
				if (entity instanceof class_3222 _serverPlayer)
					_serverPlayer.method_7335(new class_2960[]{new class_2960("xcdfvgbhnj")});
			}
		}
	}
}
