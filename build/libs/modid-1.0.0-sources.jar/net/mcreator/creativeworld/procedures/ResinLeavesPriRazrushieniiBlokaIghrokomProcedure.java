package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class ResinLeavesPriRazrushieniiBlokaIghrokomProcedure {
	public static void execute(class_1936 world, double x, double y, double z) {
		if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 10)) {
			if (world instanceof class_3218 _level) {
				class_1542 entityToSpawn = new class_1542(_level, x, y, z, new class_1799(CreativeWorldModBlocks.RESINTREESAPLING));
				entityToSpawn.method_6982(10);
				_level.method_8649(entityToSpawn);
			}
		}
	}
}
