package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1936;
import net.minecraft.class_3222;
import net.mcreator.creativeworld.init.CreativeWorldModGameRules;

public class RtyuklProcedure {
	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		if (world.method_8401().method_146().method_8355(CreativeWorldModGameRules.ALLOWCREATIVEMODE)) {
			if (CreativeWorldModItems.CREATIVEMOD == (entity instanceof class_1309 _livEnt ? _livEnt.method_6047() : class_1799.field_8037).method_7909()) {
				if (entity instanceof class_3222 _player)
					_player.method_7336(class_1934.field_9220);
				if (entity instanceof class_1309 _entity)
					_entity.method_23667(class_1268.field_5808, true);
			}
		}
	}
}
