package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class ResintreesaplingPriDobavlieniiRastieniiaProcedure {
	public static void execute(class_1936 world, double x, double y, double z) {
		new Object() {
			private int ticks = 0;

			public void startDelay(class_1936 world) {
				ServerTickEvents.END_SERVER_TICK.register((server) -> {
					this.ticks++;
					if (this.ticks == (int) (class_3532.method_15395(class_5819.method_43047(), 50, 200) * 20)) {
						if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() == CreativeWorldModBlocks.RESINTREESAPLING) {
							world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
							if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 2)) {
								if (world instanceof class_3218 _serverworld) {
									class_3499 template = _serverworld.method_14183().method_15091(new class_2960("creative_world", "resin_tree_1"));
									if (template != null) {
										template.method_15172(_serverworld, class_2338.method_49637(x, y, z), class_2338.method_49637(x, y, z), new class_3492().method_15123(class_2470.field_11467).method_15125(class_2415.field_11302).method_15133(false),
												_serverworld.field_9229, 3);
									}
								}
							} else if (1 == class_3532.method_15395(class_5819.method_43047(), 1, 2)) {
								if (world instanceof class_3218 _serverworld) {
									class_3499 template = _serverworld.method_14183().method_15091(new class_2960("creative_world", "resin_tree_2"));
									if (template != null) {
										template.method_15172(_serverworld, class_2338.method_49637(x, y, z), class_2338.method_49637(x, y, z), new class_3492().method_15123(class_2470.field_11467).method_15125(class_2415.field_11302).method_15133(false),
												_serverworld.field_9229, 3);
									}
								}
							} else {
								if (world instanceof class_3218 _serverworld) {
									class_3499 template = _serverworld.method_14183().method_15091(new class_2960("creative_world", "resin_tree_3"));
									if (template != null) {
										template.method_15172(_serverworld, class_2338.method_49637(x, y, z), class_2338.method_49637(x, y, z), new class_3492().method_15123(class_2470.field_11467).method_15125(class_2415.field_11302).method_15133(false),
												_serverworld.field_9229, 3);
									}
								}
							}
						}
						return;
					}
				});
			}
		}.startDelay(world);
	}
}
