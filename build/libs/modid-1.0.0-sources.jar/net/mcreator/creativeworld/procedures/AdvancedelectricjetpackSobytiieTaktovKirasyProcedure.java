package net.mcreator.creativeworld.procedures;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_5819;

public class AdvancedelectricjetpackSobytiieTaktovKirasyProcedure {
	public static void execute(class_1297 entity, class_1799 itemstack) {
		if (entity == null)
			return;
		if (entity instanceof class_1657 _player) {
			_player.method_31549().field_7478 = true;
			_player.method_7355();
		}
		if (entity instanceof class_1657 player && player.method_31549().field_7479) {
			{
				class_1799 _ist = itemstack;
				if (_ist.method_7970(1, class_5819.method_43047(), null)) {
					_ist.method_7934(1);
					_ist.method_7974(0);
				}
			}
		}
	}
}
