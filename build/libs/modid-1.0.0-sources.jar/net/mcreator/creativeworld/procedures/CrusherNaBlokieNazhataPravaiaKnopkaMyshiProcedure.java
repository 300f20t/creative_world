package net.mcreator.creativeworld.procedures;

import net.mcreator.creativeworld.world.inventory.FdgdfMenu;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;

import io.netty.buffer.Unpooled;

public class CrusherNaBlokieNazhataPravaiaKnopkaMyshiProcedure {
	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		{
			if (entity instanceof class_3222 _ent) {
				_ent.method_17355(new ExtendedScreenHandlerFactory() {
					final class_2338 _pos = class_2338.method_49637(x, y, z);

					@Override
					public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
						buf.method_10807(_pos);
					}

					@Override
					public class_2561 method_5476() {
						return class_2561.method_43470("Fdgdf");
					}

					@Override
					public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
						return new FdgdfMenu(syncId, inv, new class_2540(Unpooled.buffer()).method_10807(_pos));
					}
				});
			}
		}
	}
}
