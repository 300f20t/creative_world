
package net.mcreator.creativeworld.client.gui;

import net.mcreator.creativeworld.world.inventory.MsrpmroMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class MsrpmroScreen extends class_465<MsrpmroMenu> {
	private final static HashMap<String, Object> guistate = MsrpmroMenu.guistate;
	private final class_1937 world;
	private final int x, y, z;
	private final class_1657 entity;
	class_4185 button_empty;

	public MsrpmroScreen(MsrpmroMenu container, class_1661 inventory, class_2561 text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.field_2792 = 176;
		this.field_2779 = 166;
	}

	private static final class_2960 texture = new class_2960("creative_world:textures/screens/msrpmro.png");

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.method_25420(guiGraphics);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);
		this.method_2380(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void method_2389(class_332 guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.method_25290(texture, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779, this.field_2792, this.field_2779);

		guiGraphics.method_25290(new class_2960("creative_world:textures/screens/hdugfbg.png"), this.field_2776 + 51, this.field_2800 + 34, 0, 0, 16, 16, 16, 16);

		guiGraphics.method_25290(new class_2960("creative_world:textures/screens/gui_element_1_1.png"), this.field_2776 + -13, this.field_2800 + 0, 0, 0, 16, 16, 16, 16);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean method_25404(int key, int b, int c) {
		if (key == 256) {
			this.field_22787.field_1724.method_7346();
			return true;
		}
		return super.method_25404(key, b, c);
	}

	@Override
	public void method_37432() {
		super.method_37432();
	}

	@Override
	protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void method_25419() {
		super.method_25419();
	}

	@Override
	public void method_25426() {
		super.method_25426();
		button_empty = class_4185.method_46430(class_2561.method_43471("gui.creative_world.msrpmro.button_empty"), e -> {
		}).method_46434(this.field_2776 + -14, this.field_2800 + -19, 30, 20).method_46431();
		guistate.put("button:button_empty", button_empty);
		this.method_37063(button_empty);
	}
}
