
package net.mcreator.creativeworld.network;

import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import net.mcreator.creativeworld.procedures.ElectricjetpackcontrolPriNazhatiiKlavishiProcedure;

import net.fabricmc.fabric.api.networking.v1.PacketSender;

import io.netty.buffer.Unpooled;

public class ElectricjetpackcontrolMessage extends class_2540 {
	public ElectricjetpackcontrolMessage(boolean pressed, boolean released) {
		super(Unpooled.buffer());
		writeBoolean(pressed);
		writeBoolean(released);
	}

	public static void apply(MinecraftServer server, class_3222 entity, class_3244 handler, class_2540 buf, PacketSender responseSender) {
		boolean pressed = buf.readBoolean();
		boolean released = buf.readBoolean();
		server.execute(() -> {
			class_1937 world = entity.method_37908();
			double x = entity.method_23317();
			double y = entity.method_23318();
			double z = entity.method_23321();
			// security measure to prevent arbitrary chunk generation
			if (!world.method_22340(entity.method_24515()))
				return;
			if (pressed) {

				ElectricjetpackcontrolPriNazhatiiKlavishiProcedure.execute(entity);
			}
		});
	}
}
