
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

import java.lang.reflect.Type;

public abstract class ElectricjetpackItem extends class_1738 {
	public ElectricjetpackItem(class_8051 type, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_48402(class_8051 type) {
				return new int[]{13, 15, 16, 11}[type.method_48399().method_5927()] * 5;
			}

			@Override
			public int method_48403(class_8051 type) {
				return new int[]{1, 4, 5, 1}[type.method_48399().method_5927()];
			}

			@Override
			public int method_7699() {
				return 10;
			}

			@Override
			public class_3414 method_7698() {
				return null;
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_35226();
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "ej_1";
			}

			@Override
			public float method_7700() {
				return 0.2f;
			}

			@Override
			public float method_24355() {
				return 0f;
			}
		}, type, properties);
	}

	public static class Chestplate extends ElectricjetpackItem {

		public Chestplate() {
			super(class_8051.field_41935, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}
}
