
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.AdvancedelectricjetpackSobytiieTaktovKirasyProcedure;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.mcreator.creativeworld.init.CreativeWorldModItems;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

import java.lang.reflect.Type;

public abstract class AdvancedelectricjetpackItem extends class_1738 {
	public AdvancedelectricjetpackItem(class_8051 type, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_48402(class_8051 type) {
				return new int[]{13, 15, 16, 11}[type.method_48399().method_5927()] * 200;
			}

			@Override
			public int method_48403(class_8051 type) {
				return new int[]{2, 5, 6, 2}[type.method_48399().method_5927()];
			}

			@Override
			public int method_7699() {
				return 9;
			}

			@Override
			public class_3414 method_7698() {
				return null;
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_8101(new class_1799(CreativeWorldModItems.ELECTRICALCIRCUIT));
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "apvkie";
			}

			@Override
			public float method_7700() {
				return 4f;
			}

			@Override
			public float method_24355() {
				return 0.5f;
			}
		}, type, properties);
	}

	public static class Chestplate extends AdvancedelectricjetpackItem {

		public Chestplate() {
			super(class_8051.field_41935, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}

		@Override
		public void method_7888(class_1799 itemstack, class_1937 world, class_1297 entity, int slotinv, boolean selected) {
			double unique = Math.random();
			class_1799 stack = entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037;
			if (stack.method_7909() == (itemstack).method_7909()) {
				if (stack.method_7948().method_10574("_id") != unique)
					stack.method_7948().method_10549("_id", unique);
				if (itemstack.method_7948().method_10574("_id") == unique)
					AdvancedelectricjetpackSobytiieTaktovKirasyProcedure.execute(entity, itemstack);
			}
		}
	}
}
