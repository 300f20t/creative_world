
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.mcreator.creativeworld.init.CreativeWorldModItems;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

import java.lang.reflect.Type;

public abstract class TinArmorItem extends class_1738 {
	public TinArmorItem(class_8051 type, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_48402(class_8051 type) {
				return new int[]{13, 15, 16, 11}[type.method_48399().method_5927()] * 12;
			}

			@Override
			public int method_48403(class_8051 type) {
				return new int[]{2, 4, 4, 2}[type.method_48399().method_5927()];
			}

			@Override
			public int method_7699() {
				return 7;
			}

			@Override
			public class_3414 method_7698() {
				return null;
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_8101(new class_1799(CreativeWorldModItems.TIN_INGOT));
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "tin_";
			}

			@Override
			public float method_7700() {
				return 0f;
			}

			@Override
			public float method_24355() {
				return 0.1f;
			}
		}, type, properties);
	}

	public static class Helmet extends TinArmorItem {
		public Helmet() {
			super(class_8051.field_41934, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Chestplate extends TinArmorItem {

		public Chestplate() {
			super(class_8051.field_41935, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Leggings extends TinArmorItem {

		public Leggings() {
			super(class_8051.field_41936, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Boots extends TinArmorItem {

		public Boots() {
			super(class_8051.field_41937, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}
}
