
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.Alargebucketofwater9DopolnitielnaiaInformatsiiaProcedure;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class AlargebucketItem extends class_1792 {
	public AlargebucketItem() {
		super(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8906));
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS).register(content -> content.method_45421(this));
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		class_1297 entity = itemstack.method_27319();
		double x = entity != null ? entity.method_23317() : 0.0;
		double y = entity != null ? entity.method_23318() : 0.0;
		double z = entity != null ? entity.method_23321() : 0.0;
		list.add(class_2561.method_43470(Alargebucketofwater9DopolnitielnaiaInformatsiiaProcedure.execute(itemstack)));
	}
}
