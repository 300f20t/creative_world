
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.mcreator.creativeworld.init.CreativeWorldModItems;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;

import java.lang.reflect.Type;

public abstract class CreativiumArmorItem extends class_1738 {
	public CreativiumArmorItem(class_8051 type, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_48402(class_8051 type) {
				return new int[]{13, 15, 16, 11}[type.method_48399().method_5927()] * 128;
			}

			@Override
			public int method_48403(class_8051 type) {
				return new int[]{24, 32, 32, 24}[type.method_48399().method_5927()];
			}

			@Override
			public int method_7699() {
				return 64;
			}

			@Override
			public class_3414 method_7698() {
				return null;
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_8101(new class_1799(CreativeWorldModItems.CREATIVIUM_INGOT));
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "creativium";
			}

			@Override
			public float method_7700() {
				return 4f;
			}

			@Override
			public float method_24355() {
				return 1f;
			}
		}, type, properties);
	}

	public static class Helmet extends CreativiumArmorItem {
		public Helmet() {
			super(class_8051.field_41934, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Chestplate extends CreativiumArmorItem {

		public Chestplate() {
			super(class_8051.field_41935, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Leggings extends CreativiumArmorItem {

		public Leggings() {
			super(class_8051.field_41936, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}

	public static class Boots extends CreativiumArmorItem {

		public Boots() {
			super(class_8051.field_41937, new class_1792.class_1793());
			ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDCOMBAT).register(content -> content.method_45421(this));
		}

		@Override
		public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
			super.method_7851(itemstack, world, list, flag);
		}
	}
}
