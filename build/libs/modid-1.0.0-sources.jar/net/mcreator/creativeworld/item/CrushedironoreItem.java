
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.CrushedironoreKoghdaNazhataPKMPoBlokuProcedure;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class CrushedironoreItem extends class_1792 {
	public CrushedironoreItem() {
		super(new class_1792.class_1793().method_7889(64).method_7894(class_1814.field_8906));
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS).register(content -> content.method_45421(this));
	}

	@Override
	public class_1839 method_7853(class_1799 itemstack) {
		return class_1839.field_8950;
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1269 retval = super.method_7884(context);
		CrushedironoreKoghdaNazhataPKMPoBlokuProcedure.execute(context.method_8045(), context.method_8037().method_10263(), context.method_8037().method_10264(), context.method_8037().method_10260(), context.method_8036());
		return retval;
	}
}
