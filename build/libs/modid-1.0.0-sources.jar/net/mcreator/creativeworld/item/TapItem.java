
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.TapKoghdaNazhataPKMPoBlokuProcedure;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_5134;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;

public class TapItem extends class_1792 {
	public TapItem() {
		super(new class_1792.class_1793().method_7895(25));
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDTOOLS).register(content -> content.method_45421(this));
	}

	@Override
	public float method_7865(class_1799 itemstack, class_2680 blockstate) {
		return 1f;
	}

	@Override
	public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 entity) {
		stack.method_7956(1, entity, i -> i.method_20235(class_1304.field_6173));
		return true;
	}

	@Override
	public boolean method_7873(class_1799 stack, class_1309 entity, class_1309 sourceentity) {
		stack.method_7956(2, sourceentity, i -> i.method_20235(class_1304.field_6173));
		return true;
	}

	@Override
	public int method_7837() {
		return 2;
	}

	@Override
	public Multimap<class_1320, class_1322> method_7844(class_1304 equipmentSlot) {
		if (equipmentSlot == class_1304.field_6173) {
			ImmutableMultimap.Builder<class_1320, class_1322> builder = ImmutableMultimap.builder();
			builder.putAll(super.method_7844(equipmentSlot));
			builder.put(class_5134.field_23721, new class_1322(field_8006, "Tool modifier", 2f, class_1322.class_1323.field_6328));
			builder.put(class_5134.field_23723, new class_1322(field_8001, "Tool modifier", -3, class_1322.class_1323.field_6328));
			return builder.build();
		}
		return super.method_7844(equipmentSlot);
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1269 retval = super.method_7884(context);
		TapKoghdaNazhataPKMPoBlokuProcedure.execute(context.method_8045(), context.method_8037().method_10263(), context.method_8037().method_10264(), context.method_8037().method_10260(), context.method_8036(), context.method_8041());
		return retval;
	}
}
