
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.RtyuklProcedure;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class CreativemodItem extends class_1792 {
	public CreativemodItem() {
		super(new class_1792.class_1793().method_7889(64).method_7894(class_1814.field_8904));
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS).register(content -> content.method_45421(this));
	}

	@Override
	public class_1839 method_7853(class_1799 itemstack) {
		return class_1839.field_8950;
	}

	@Override
	public int method_7881(class_1799 itemstack) {
		return 0;
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		list.add(class_2561.method_43470("\u00A7ehas incomplete functionality (in development)"));
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
		class_1271<class_1799> ar = super.method_7836(world, entity, hand);
		RtyuklProcedure.execute(world, entity);
		return ar;
	}
}
