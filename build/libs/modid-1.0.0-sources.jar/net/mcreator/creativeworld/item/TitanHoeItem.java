
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.creativeworld.init.CreativeWorldModItems;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class TitanHoeItem extends class_1794 {
	public TitanHoeItem() {
		super(new class_1832() {
			public int method_8025() {
				return 2380;
			}

			public float method_8027() {
				return 16f;
			}

			public float method_8028() {
				return 8f;
			}

			public int method_8024() {
				return 10;
			}

			public int method_8026() {
				return 70;
			}

			public class_1856 method_8023() {
				return class_1856.method_8101(new class_1799(CreativeWorldModItems.TITAN_INGOT));
			}
		}, 0, -3f, new class_1792.class_1793());
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDTOOLS).register(content -> content.method_45421(this));
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
	}
}
