
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.init.CreativeWorldModTabs;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class CopperPickaxeItem extends class_1810 {
	public CopperPickaxeItem() {
		super(new class_1832() {
			public int method_8025() {
				return 216;
			}

			public float method_8027() {
				return 6f;
			}

			public float method_8028() {
				return 0f;
			}

			public int method_8024() {
				return 2;
			}

			public int method_8026() {
				return 13;
			}

			public class_1856 method_8023() {
				return class_1856.method_35226();
			}
		}, 1, -3f, new class_1792.class_1793());
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDTOOLS).register(content -> content.method_45421(this));
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
	}
}
