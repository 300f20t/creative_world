
package net.mcreator.creativeworld.item;

import net.mcreator.creativeworld.procedures.BedrockbreackerPriShchielchkiePravoiKnopkoiMyshiNaBlokieProcedure;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2561;
import net.mcreator.creativeworld.init.CreativeWorldModTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import java.util.List;

public class BedrockbreackerItem extends class_1810 {
	public BedrockbreackerItem() {
		super(new class_1832() {
			public int method_8025() {
				return 5;
			}

			public float method_8027() {
				return 10f;
			}

			public float method_8028() {
				return 5f;
			}

			public int method_8024() {
				return 4;
			}

			public int method_8026() {
				return 20;
			}

			public class_1856 method_8023() {
				return class_1856.method_8101(new class_1799(class_2246.field_22423), new class_1799(class_1802.field_8477));
			}
		}, 1, -2.4f, new class_1792.class_1793().method_24359());
		ItemGroupEvents.modifyEntriesEvent(CreativeWorldModTabs.TAB_CREATIVEWORLDTOOLS).register(content -> content.method_45421(this));
	}

	@Override
	public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
		super.method_7851(itemstack, world, list, flag);
		list.add(class_2561.method_43470("destroy bedrock"));
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1269 retval = super.method_7884(context);
		BedrockbreackerPriShchielchkiePravoiKnopkoiMyshiNaBlokieProcedure.execute(context.method_8045(), context.method_8037().method_10263(), context.method_8037().method_10264(), context.method_8037().method_10260(), context.method_8036(), context.method_8041());
		return retval;
	}
}
