
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.world.inventory.MsrpmroMenu;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import net.mcreator.creativeworld.world.inventory.FgfhffhghkjkkytwqaMenu;
import net.mcreator.creativeworld.world.inventory.FdgdfMenu;
import net.mcreator.creativeworld.CreativeWorldMod;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;

public class CreativeWorldModMenus {
	public static class_3917<MsrpmroMenu> MSRPMRO;
	public static class_3917<FdgdfMenu> FDGDF;
	public static class_3917<FgfhffhghkjkkytwqaMenu> FGFHFFHGHKJKKYTWQA;

	public static void load() {
		MSRPMRO = class_2378.method_10230(class_7923.field_41187, new class_2960(CreativeWorldMod.MODID, "msrpmro"), new ExtendedScreenHandlerType<>(MsrpmroMenu::new));
		MsrpmroMenu.screenInit();
		FDGDF = class_2378.method_10230(class_7923.field_41187, new class_2960(CreativeWorldMod.MODID, "fdgdf"), new ExtendedScreenHandlerType<>(FdgdfMenu::new));
		FdgdfMenu.screenInit();
		FGFHFFHGHKJKKYTWQA = class_2378.method_10230(class_7923.field_41187, new class_2960(CreativeWorldMod.MODID, "fgfhffhghkjkkytwqa"), new ExtendedScreenHandlerType<>(FgfhffhghkjkkytwqaMenu::new));
		FgfhffhghkjkkytwqaMenu.screenInit();
	}
}
