
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.block.entity.SolarpanelBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.mcreator.creativeworld.block.entity.InfinityenergyBlockEntity;
import net.mcreator.creativeworld.block.entity.FanBlockEntity;
import net.mcreator.creativeworld.block.entity.CrusherBlockEntity;
import net.mcreator.creativeworld.block.entity.CoalgeneratorBlockEntity;
import net.mcreator.creativeworld.block.entity.Coalgenerator1BlockEntity;
import net.mcreator.creativeworld.block.entity.BatteryblockBlockEntity;
import net.mcreator.creativeworld.CreativeWorldMod;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

public class CreativeWorldModBlockEntities {
	public static class_2591<?> COALGENERATOR;
	public static class_2591<?> CRUSHER;
	public static class_2591<?> FAN;
	public static class_2591<?> BATTERYBLOCK;
	public static class_2591<?> SOLARPANEL;
	public static class_2591<?> INFINITYENERGY;
	public static class_2591<?> COALGENERATOR_1;

	public static void load() {
		COALGENERATOR = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "coalgenerator"),
				FabricBlockEntityTypeBuilder.create(CoalgeneratorBlockEntity::new, CreativeWorldModBlocks.COALGENERATOR).build(null));
		CRUSHER = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "crusher"), FabricBlockEntityTypeBuilder.create(CrusherBlockEntity::new, CreativeWorldModBlocks.CRUSHER).build(null));
		FAN = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "fan"), FabricBlockEntityTypeBuilder.create(FanBlockEntity::new, CreativeWorldModBlocks.FAN).build(null));
		BATTERYBLOCK = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "batteryblock"),
				FabricBlockEntityTypeBuilder.create(BatteryblockBlockEntity::new, CreativeWorldModBlocks.BATTERYBLOCK).build(null));
		SOLARPANEL = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "solarpanel"), FabricBlockEntityTypeBuilder.create(SolarpanelBlockEntity::new, CreativeWorldModBlocks.SOLARPANEL).build(null));
		INFINITYENERGY = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "infinityenergy"),
				FabricBlockEntityTypeBuilder.create(InfinityenergyBlockEntity::new, CreativeWorldModBlocks.INFINITYENERGY).build(null));
		COALGENERATOR_1 = class_2378.method_10230(class_7923.field_41181, new class_2960(CreativeWorldMod.MODID, "coalgenerator_1"),
				FabricBlockEntityTypeBuilder.create(Coalgenerator1BlockEntity::new, CreativeWorldModBlocks.COALGENERATOR_1).build(null));
	}
}
