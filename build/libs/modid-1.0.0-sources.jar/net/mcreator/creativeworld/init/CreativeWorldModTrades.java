
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.creativeworld.init;

import org.jetbrains.annotations.NotNull;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_3852;
import net.minecraft.class_3853;
import net.minecraft.class_5819;

public class CreativeWorldModTrades {
	public static void registerTrades() {
		TradeOfferHelper.registerVillagerOffers(class_3852.field_17059, 1, factories -> {
			factories.add(new BasicTrade(new class_1799(class_1802.field_8687), class_1799.field_8037, new class_1799(CreativeWorldModItems.RUBBER, 5), 10, 5, 0.05f));
		});
	}

	private record BasicTrade(class_1799 price, class_1799 price2, class_1799 offer, int maxTrades, int xp, float priceMult) implements class_3853.class_1652 {
		@Override
		public @NotNull class_1914 method_7246(class_1297 entity, class_5819 random) {
			return new class_1914(price, price2, offer, maxTrades, xp, priceMult);
		}
	}
}
