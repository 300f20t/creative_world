
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.world.features.configurations.StructureFeatureConfiguration;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3122;
import net.minecraft.class_3124;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.mcreator.creativeworld.world.features.StructureFeature;
import net.mcreator.creativeworld.block.TitanOreBlock;
import net.mcreator.creativeworld.block.TinOreBlock;
import net.mcreator.creativeworld.block.CreativiumOreBlock;
import net.mcreator.creativeworld.block.AccumulatiumOreBlock;
import net.mcreator.creativeworld.CreativeWorldMod;

import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;

import java.util.function.Predicate;

public class CreativeWorldModFeatures {
	public static void load() {
		register("tin_ore", new class_3122(class_3124.field_24896), TinOreBlock.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		register("titan_ore", new class_3122(class_3124.field_24896), TitanOreBlock.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		register("accumulatium_ore", new class_3122(class_3124.field_24896), AccumulatiumOreBlock.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		register("creativium_ore", new class_3122(class_3124.field_24896), CreativiumOreBlock.GENERATE_BIOMES, class_2893.class_2895.field_13176);
		class_2378.method_10230(class_7923.field_41144, new class_2960(CreativeWorldMod.MODID, "structure_feature"), new StructureFeature(StructureFeatureConfiguration.CODEC));
	}

	public static void register(String registryName, class_3031 feature, Predicate<BiomeSelectionContext> biomes, class_2893.class_2895 genStep) {
		class_2378.method_10230(class_7923.field_41144, new class_2960(CreativeWorldMod.MODID, registryName), feature);
		BiomeModifications.addFeature(biomes, genStep, class_5321.method_29179(class_7924.field_41245, new class_2960(CreativeWorldMod.MODID, registryName)));
	}
}
