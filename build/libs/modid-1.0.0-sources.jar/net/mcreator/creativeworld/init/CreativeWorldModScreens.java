
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.client.gui.MsrpmroScreen;
import net.minecraft.class_3929;
import net.mcreator.creativeworld.client.gui.FgfhffhghkjkkytwqaScreen;
import net.mcreator.creativeworld.client.gui.FdgdfScreen;

public class CreativeWorldModScreens {
	public static void load() {
		class_3929.method_17542(CreativeWorldModMenus.MSRPMRO, MsrpmroScreen::new);
		class_3929.method_17542(CreativeWorldModMenus.FDGDF, FdgdfScreen::new);
		class_3929.method_17542(CreativeWorldModMenus.FGFHFFHGHKJKKYTWQA, FgfhffhghkjkkytwqaScreen::new);
	}
}
