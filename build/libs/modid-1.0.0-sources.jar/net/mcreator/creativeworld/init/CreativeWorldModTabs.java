
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.CreativeWorldMod;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class CreativeWorldModTabs {
	public static class_5321<class_1761> TAB_CREATIVEWORLDITEMS = class_5321.method_29179(class_7924.field_44688, new class_2960(CreativeWorldMod.MODID, "creativeworlditems"));
	public static class_5321<class_1761> TAB_CREATIVEWORLDBLOCKS = class_5321.method_29179(class_7924.field_44688, new class_2960(CreativeWorldMod.MODID, "creativeworldblocks"));
	public static class_5321<class_1761> TAB_CREATIVEWORLDTOOLS = class_5321.method_29179(class_7924.field_44688, new class_2960(CreativeWorldMod.MODID, "creativeworldtools"));
	public static class_5321<class_1761> TAB_CREATIVEWORLDCOMBAT = class_5321.method_29179(class_7924.field_44688, new class_2960(CreativeWorldMod.MODID, "creativeworldcombat"));

	public static void load() {
		class_2378.method_39197(class_7923.field_44687, TAB_CREATIVEWORLDITEMS,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group." + CreativeWorldMod.MODID + ".creativeworlditems")).method_47320(() -> new class_1799(CreativeWorldModItems.CARBONPLATE)).method_47324());
		class_2378.method_39197(class_7923.field_44687, TAB_CREATIVEWORLDBLOCKS,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group." + CreativeWorldMod.MODID + ".creativeworldblocks")).method_47320(() -> new class_1799(CreativeWorldModBlocks.ADVENCEDMACHINECASE)).method_47324());
		class_2378.method_39197(class_7923.field_44687, TAB_CREATIVEWORLDTOOLS,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group." + CreativeWorldMod.MODID + ".creativeworldtools")).method_47320(() -> new class_1799(CreativeWorldModItems.BEDROCKBREACKER)).method_47324());
		class_2378.method_39197(class_7923.field_44687, TAB_CREATIVEWORLDCOMBAT,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group." + CreativeWorldMod.MODID + ".creativeworldcombat")).method_47320(() -> new class_1799(CreativeWorldModItems.CREATIVIUM_SWORD)).method_47324());
	}
}
