
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;

public class CreativeWorldModGameRules {
	public static class_1928.class_4313<class_1928.class_4310> ALLOWCREATIVEMODE;
	public static class_1928.class_4313<class_1928.class_4310> ALLOW_CHEAT_ITEMS;

	public static void load() {
		ALLOWCREATIVEMODE = GameRuleRegistry.register("allowcreativemode", class_1928.class_5198.field_24094, GameRuleFactory.createBooleanRule(false));
		ALLOW_CHEAT_ITEMS = GameRuleRegistry.register("allow_cheat_items", class_1928.class_5198.field_24094, GameRuleFactory.createBooleanRule(false));
	}
}
