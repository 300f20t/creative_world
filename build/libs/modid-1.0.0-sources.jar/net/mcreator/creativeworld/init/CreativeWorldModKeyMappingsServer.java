
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.mcreator.creativeworld.network.ElectricjetpackcontrolMessage;
import net.minecraft.class_2960;
import net.mcreator.creativeworld.network.DrillModeSwitchMessage;
import net.mcreator.creativeworld.CreativeWorldMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class CreativeWorldModKeyMappingsServer {
	public static void serverLoad() {
		ServerPlayNetworking.registerGlobalReceiver(new class_2960(CreativeWorldMod.MODID, "electricjetpackcontrol"), ElectricjetpackcontrolMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new class_2960(CreativeWorldMod.MODID, "drill_mode_switch"), DrillModeSwitchMessage::apply);
	}
}
