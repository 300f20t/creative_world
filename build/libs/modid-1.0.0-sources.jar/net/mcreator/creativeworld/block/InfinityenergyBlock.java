
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1264;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.mcreator.creativeworld.block.entity.InfinityenergyBlockEntity;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class InfinityenergyBlock extends class_2248 implements class_2343 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_9629(1f, 10f).method_26247((bs, br, bp) -> true).method_26249((bs, br, bp) -> true);

	public InfinityenergyBlock() {
		super(PROPERTIES);
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 15;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Override
	public class_3908 method_17454(class_2680 state, class_1937 worldIn, class_2338 pos) {
		class_2586 tileEntity = worldIn.method_8321(pos);
		return tileEntity instanceof class_3908 ? (class_3908) tileEntity : null;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new InfinityenergyBlockEntity(pos, state);
	}

	@Override
	public boolean method_9592(class_2680 state, class_1937 world, class_2338 pos, int eventID, int eventParam) {
		super.method_9592(state, world, pos, eventID, eventParam);
		class_2586 blockEntity = world.method_8321(pos);
		return blockEntity == null ? false : blockEntity.method_11004(eventID, eventParam);
	}

	@Override
	public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean isMoving) {
		if (state.method_26204() != newState.method_26204()) {
			class_2586 blockEntity = world.method_8321(pos);
			if (blockEntity instanceof InfinityenergyBlockEntity be) {
				class_1264.method_5451(world, pos, be);
				world.method_8455(pos, this);
			}
			super.method_9536(state, world, pos, newState, isMoving);
		}
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 blockState, class_1937 world, class_2338 pos) {
		class_2586 tileentity = world.method_8321(pos);
		if (tileentity instanceof InfinityenergyBlockEntity be)
			return class_1703.method_7618(be);
		else
			return 0;
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.INFINITYENERGY, class_1921.method_23577());
	}
}
