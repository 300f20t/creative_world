
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2766;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class ResinWoodBlock extends class_2248 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_50013().method_51368(class_2766.field_12651).method_29292().method_9626(class_2498.field_11547).method_9632(2f).method_29292();
	public static final class_2754<class_2350.class_2351> AXIS = class_2741.field_12496;

	public ResinWoodBlock() {
		super(PROPERTIES);
		this.method_9590(this.field_10647.method_11664().method_11657(AXIS, class_2350.class_2351.field_11052));
		FlammableBlockRegistry.getDefaultInstance().add(this, 5, 0);
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 15;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(AXIS);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return this.method_9564().method_11657(AXIS, context.method_8038().method_10166());
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		if (rot == class_2470.field_11463 || rot == class_2470.field_11465) {
			if ((class_2350.class_2351) state.method_11654(AXIS) == class_2350.class_2351.field_11048) {
				return state.method_11657(AXIS, class_2350.class_2351.field_11051);
			} else if ((class_2350.class_2351) state.method_11654(AXIS) == class_2350.class_2351.field_11051) {
				return state.method_11657(AXIS, class_2350.class_2351.field_11048);
			}
		}
		return state;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.RESIN_WOOD, class_1921.method_23577());
	}
}
