package net.mcreator.creativeworld.block.entity;

import org.jetbrains.annotations.Nullable;
import net.mcreator.creativeworld.init.CreativeWorldModBlockEntities;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2621;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;

import java.util.stream.IntStream;

public class InfinityenergyBlockEntity extends class_2621 implements ExtendedScreenHandlerFactory, class_1278 {
	private class_2371<class_1799> stacks = class_2371.<class_1799>method_10213(9, class_1799.field_8037);

	public InfinityenergyBlockEntity(class_2338 position, class_2680 state) {
		super(CreativeWorldModBlockEntities.INFINITYENERGY, position, state);
	}

	@Override
	public void method_11014(class_2487 compound) {
		super.method_11014(compound);
		if (!this.method_11283(compound))
			this.stacks = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
		class_1262.method_5429(compound, this.stacks);
	}

	@Override
	public void method_11007(class_2487 compound) {
		super.method_11007(compound);
		if (!this.method_11286(compound))
			class_1262.method_5426(compound, this.stacks);
	}

	@Override
	public class_2622 method_38235() {
		return class_2622.method_38585(this);
	}

	@Override
	public class_2487 method_16887() {
		return this.method_38244();
	}

	@Override
	public int method_5439() {
		return stacks.size();
	}

	@Override
	public boolean method_5442() {
		for (class_1799 itemstack : this.stacks)
			if (!itemstack.method_7960())
				return false;
		return true;
	}

	@Override
	public class_2561 method_17823() {
		return class_2561.method_43470("infinityenergy");
	}

	@Override
	public int method_5444() {
		return 64;
	}

	@Override
	public class_1703 method_5465(int id, class_1661 inventory) {
		return class_1707.method_19248(id, inventory);
	}

	@Override
	public class_2561 method_5476() {
		return class_2561.method_43470("Infinity energy");
	}

	@Override
	protected class_2371<class_1799> method_11282() {
		return this.stacks;
	}

	@Override
	protected void method_11281(class_2371<class_1799> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean method_5437(int index, class_1799 stack) {
		return true;
	}

	@Override
	public int[] method_5494(class_2350 side) {
		return IntStream.range(0, this.method_5439()).toArray();
	}

	@Override
	public boolean method_5492(int index, class_1799 stack, @Nullable class_2350 direction) {
		return this.method_5437(index, stack);
	}

	@Override
	public boolean method_5493(int index, class_1799 stack, class_2350 direction) {
		return true;
	}

	@Override
	public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
		buf.method_10807(field_11867);
	}
}
