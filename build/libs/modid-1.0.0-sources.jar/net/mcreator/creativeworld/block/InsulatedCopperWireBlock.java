
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class InsulatedCopperWireBlock extends class_2248 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_51368(class_2766.field_12653).method_9626(class_2498.field_11529).method_9629(1f, 10f).method_22488().method_26236((bs, br, bp) -> false);

	public InsulatedCopperWireBlock() {
		super(PROPERTIES);
	}

	@Override
	public boolean method_9579(class_2680 state, class_1922 reader, class_2338 pos) {
		return true;
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 0;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.INSULATED_COPPER_WIRE, class_1921.method_23577());
	}
}
