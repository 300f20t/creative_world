
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2341;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_2766;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class StationaryparticlebinderBlock extends class_2248 implements class_3737 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_51368(class_2766.field_12653).method_9626(class_2498.field_11533).method_9629(1f, 10f).method_22488().method_26236((bs, br, bp) -> false);
	public static final class_2753 FACING = class_2383.field_11177;
	public static final class_2754<class_2738> FACE = class_2341.field_11007;
	public static final class_2746 WATERLOGGED = class_2741.field_12508;

	public StationaryparticlebinderBlock() {
		super(PROPERTIES);
		this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(FACE, class_2738.field_12471).method_11657(WATERLOGGED, false));
	}

	@Override
	public boolean method_9579(class_2680 state, class_1922 reader, class_2338 pos) {
		return state.method_26227().method_15769();
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 0;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, FACE, WATERLOGGED);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		boolean flag = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
		return this.method_9564().method_11657(FACE, faceForDirection(context.method_7715())).method_11657(FACING, context.method_8042().method_10153()).method_11657(WATERLOGGED, flag);
	}

	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
	}

	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state.method_26186(mirrorIn.method_10345(state.method_11654(FACING)));
	}

	private class_2738 faceForDirection(class_2350 direction) {
		if (direction.method_10166() == class_2350.class_2351.field_11052)
			return direction == class_2350.field_11036 ? class_2738.field_12473 : class_2738.field_12475;
		else
			return class_2738.field_12471;
	}

	@Override
	public class_3610 method_9545(class_2680 state) {
		return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 facing, class_2680 facingState, class_1936 world, class_2338 currentPos, class_2338 facingPos) {
		if (state.method_11654(WATERLOGGED)) {
			world.method_39281(currentPos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
		}
		return super.method_9559(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.STATIONARYPARTICLEBINDER, class_1921.method_23577());
	}
}
