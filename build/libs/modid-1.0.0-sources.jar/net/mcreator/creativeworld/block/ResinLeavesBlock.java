
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.procedures.ResinLeavesPriRazrushieniiBlokaIghrokomProcedure;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.mcreator.creativeworld.init.CreativeWorldModBlocks;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class ResinLeavesBlock extends class_2397 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_50013().method_9626(class_2498.field_11535).method_9632(0.2f).method_22488();

	public ResinLeavesBlock() {
		super(PROPERTIES);
		FlammableBlockRegistry.getDefaultInstance().add(this, 30, 0);
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 1;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(class_2246.field_10124));
	}

	@Override
	public void method_9556(class_1937 world, class_1657 entity, class_2338 pos, class_2680 blockstate, class_2586 blockEntity, class_1799 itemStack) {
		super.method_9556(world, entity, pos, blockstate, blockEntity, itemStack);
		ResinLeavesPriRazrushieniiBlokaIghrokomProcedure.execute(world, pos.method_10263(), pos.method_10264(), pos.method_10260());
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.RESIN_LEAVES, class_1921.method_23577());
	}
}
