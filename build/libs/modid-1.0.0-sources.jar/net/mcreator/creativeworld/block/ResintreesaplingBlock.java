
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.procedures.ResintreesaplingPriDobavlieniiRastieniiaProcedure;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2356;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.mcreator.creativeworld.init.CreativeWorldModBlocks;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class ResintreesaplingBlock extends class_2356 {
	public ResintreesaplingBlock() {
		super(class_1294.field_5908, 100, class_4970.class_2251.method_9637().method_9626(class_2498.field_11535).method_9618().method_9634());
		FlammableBlockRegistry.getDefaultInstance().add(this, 100, 60);
	}

	@Override
	public int method_10187() {
		return 100;
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Override
	public boolean method_9695(class_2680 groundState, class_1922 worldIn, class_2338 pos) {
		return groundState.method_27852(class_2246.field_10219) || groundState.method_27852(class_2246.field_10566);
	}

	@Override
	public boolean method_9558(class_2680 blockstate, class_4538 worldIn, class_2338 pos) {
		class_2338 blockpos = pos.method_10074();
		class_2680 groundState = worldIn.method_8320(blockpos);
		return this.method_9695(groundState, worldIn, blockpos);
	}

	@Override
	public void method_9615(class_2680 blockstate, class_1937 world, class_2338 pos, class_2680 oldState, boolean moving) {
		super.method_9615(blockstate, world, pos, oldState, moving);
		ResintreesaplingPriDobavlieniiRastieniiaProcedure.execute(world, pos.method_10263(), pos.method_10264(), pos.method_10260());
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.RESINTREESAPLING, class_1921.method_23579());
	}
}
