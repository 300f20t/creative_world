
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.function.Predicate;

public class TinOreBlock extends class_2248 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_51368(class_2766.field_12653).method_29292().method_9626(class_2498.field_11544).method_9629(2.4f, 4.1825582104f).method_29292();
	public static final Predicate<BiomeSelectionContext> GENERATE_BIOMES = BiomeSelectors.tag(class_6862.method_40092(class_7924.field_41236, new class_2960("is_overworld")));

	public TinOreBlock() {
		super(PROPERTIES);
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 15;
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.TIN_ORE, class_1921.method_23577());
	}
}
