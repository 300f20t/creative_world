
package net.mcreator.creativeworld.block;

import net.mcreator.creativeworld.procedures.CrusherNaBlokieNazhataPravaiaKnopkaMyshiProcedure;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_8567;
import net.mcreator.creativeworld.init.CreativeWorldModBlocks;
import net.mcreator.creativeworld.block.entity.CrusherBlockEntity;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.List;
import java.util.Collections;

public class CrusherBlock extends class_2248 implements class_2343 {
	public static class_4970.class_2251 PROPERTIES = class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_9629(1f, 10f);
	public static final class_2753 FACING = class_2383.field_11177;

	public CrusherBlock() {
		super(PROPERTIES);
		this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
	}

	@Override
	public int method_9505(class_2680 state, class_1922 worldIn, class_2338 pos) {
		return 15;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
	}

	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
	}

	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state.method_26186(mirrorIn.method_10345(state.method_11654(FACING)));
	}

	@Override
	public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
		List<class_1799> dropsOriginal = super.method_9560(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new class_1799(this, 1));
	}

	@Override
	public class_1269 method_9534(class_2680 blockstate, class_1937 world, class_2338 pos, class_1657 entity, class_1268 hand, class_3965 hit) {
		super.method_9534(blockstate, world, pos, entity, hand, hit);
		if (!world.field_9236) {
			class_3908 menuProvider = blockstate.method_26196(world, pos);
			if (menuProvider != null)
				entity.method_17355(menuProvider);
		}
		int x = pos.method_10263();
		int y = pos.method_10264();
		int z = pos.method_10260();
		double hitX = hit.method_17784().field_1352;
		double hitY = hit.method_17784().field_1351;
		double hitZ = hit.method_17784().field_1350;
		class_2350 direction = hit.method_17780();
		CrusherNaBlokieNazhataPravaiaKnopkaMyshiProcedure.execute(world, x, y, z, entity);
		return class_1269.field_5812;
	}

	@Override
	public class_3908 method_17454(class_2680 state, class_1937 worldIn, class_2338 pos) {
		class_2586 tileEntity = worldIn.method_8321(pos);
		return tileEntity instanceof class_3908 ? (class_3908) tileEntity : null;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new CrusherBlockEntity(pos, state);
	}

	@Override
	public boolean method_9592(class_2680 state, class_1937 world, class_2338 pos, int eventID, int eventParam) {
		super.method_9592(state, world, pos, eventID, eventParam);
		class_2586 blockEntity = world.method_8321(pos);
		return blockEntity == null ? false : blockEntity.method_11004(eventID, eventParam);
	}

	@Override
	public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean isMoving) {
		if (state.method_26204() != newState.method_26204()) {
			class_2586 blockEntity = world.method_8321(pos);
			if (blockEntity instanceof CrusherBlockEntity be) {
				class_1264.method_5451(world, pos, be);
				world.method_8455(pos, this);
			}
			super.method_9536(state, world, pos, newState, isMoving);
		}
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 blockState, class_1937 world, class_2338 pos) {
		class_2586 tileentity = world.method_8321(pos);
		if (tileentity instanceof CrusherBlockEntity be)
			return class_1703.method_7618(be);
		else
			return 0;
	}

	@Environment(EnvType.CLIENT)
	public static void clientInit() {
		BlockRenderLayerMap.INSTANCE.putBlock(CreativeWorldModBlocks.CRUSHER, class_1921.method_23577());
	}
}
