package net.mcreator.creativeworld.world.features;

import net.mcreator.creativeworld.world.features.configurations.StructureFeatureConfiguration;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_3031;
import net.minecraft.class_3485;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3793;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_6880;
import com.mojang.serialization.Codec;

public class StructureFeature extends class_3031<StructureFeatureConfiguration> {
	public StructureFeature(Codec<StructureFeatureConfiguration> codec) {
		super(codec);
	}

	public boolean method_13151(class_5821<StructureFeatureConfiguration> context) {
		class_5819 random = context.method_33654();
		class_5281 worldGenLevel = context.method_33652();
		StructureFeatureConfiguration config = context.method_33656();
		class_2470 rotation = config.randomRotation() ? class_2470.method_16548(random) : class_2470.field_11467;
		class_2415 mirror = config.randomMirror() ? class_2415.values()[random.method_43048(2)] : class_2415.field_11302;
		class_2338 placePos = context.method_33655().method_10081(config.offset());
		// Load the structure template
		class_3485 structureManager = worldGenLevel.method_8410().method_8503().method_27727();
		class_3499 template = structureManager.method_15091(config.structure());
		class_3492 placeSettings = (new class_3492()).method_15123(rotation).method_15125(mirror).method_15112(random).method_15133(false)
				.method_16184(new class_3793(config.ignoredBlocks().method_40239().map(class_6880::comp_349).toList()));
		template.method_15172(worldGenLevel, placePos, placePos, placeSettings, random, 4);
		return true;
	}
}
