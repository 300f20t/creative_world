package net.mcreator.creativeworld.world.features.configurations;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2382;
import net.minecraft.class_2960;
import net.minecraft.class_3037;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_7924;
import com.mojang.serialization.Codec;

public record StructureFeatureConfiguration(class_2960 structure, boolean randomRotation, boolean randomMirror, class_6885<class_2248> ignoredBlocks, class_2382 offset) implements class_3037 {
	public static final Codec<StructureFeatureConfiguration> CODEC = RecordCodecBuilder.create(builder -> {
		return builder.group(class_2960.field_25139.fieldOf("structure").forGetter(config -> {
			return config.structure;
		}), Codec.BOOL.fieldOf("random_rotation").orElse(false).forGetter(config -> {
			return config.randomRotation;
		}), Codec.BOOL.fieldOf("random_mirror").orElse(false).forGetter(config -> {
			return config.randomMirror;
		}), class_6895.method_40340(class_7924.field_41254).fieldOf("ignored_blocks").forGetter(config -> {
			return config.ignoredBlocks;
		}), class_2382.method_39677(48).optionalFieldOf("offset", class_2382.field_11176).forGetter(config -> {
			return config.offset;
		})).apply(builder, StructureFeatureConfiguration::new);
	});
}
