
package net.mcreator.creativeworld.world.inventory;

import net.mcreator.creativeworld.init.CreativeWorldModMenus;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import java.util.HashMap;

public class MsrpmroMenu extends class_1703 {
	public final static HashMap<String, Object> guistate = new HashMap<>();
	public final class_1937 world;
	public final class_1657 entity;
	public int x, y, z;
	private class_2338 pos;
	private final class_1263 inventory;
	private boolean bound = false;

	public MsrpmroMenu(int id, class_1661 inv, class_2540 extraData) {
		this(id, inv, new class_1277(2));
		if (extraData != null) {
			pos = extraData.method_10811();
			this.x = pos.method_10263();
			this.y = pos.method_10264();
			this.z = pos.method_10260();
		}
	}

	public MsrpmroMenu(int id, class_1661 inv, class_1263 container) {
		super(CreativeWorldModMenus.MSRPMRO, id);
		this.entity = inv.field_7546;
		this.world = inv.field_7546.method_37908();
		this.inventory = container;
		this.method_7621(new class_1735(inventory, 0, 52, 17) {
			private final int slot = 0;

			@Override
			public boolean method_7680(class_1799 stack) {
				return false;
			}
		});
		this.method_7621(new class_1735(inventory, 1, 52, 53) {
			private final int slot = 1;
		});
		for (int si = 0; si < 3; ++si)
			for (int sj = 0; sj < 9; ++sj)
				this.method_7621(new class_1735(inv, sj + (si + 1) * 9, 0 + 8 + sj * 18, 0 + 84 + si * 18));
		for (int si = 0; si < 9; ++si)
			this.method_7621(new class_1735(inv, si, 0 + 8 + si * 18, 0 + 142));
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return this.inventory.method_5443(player);
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1799 itemstack = class_1799.field_8037;
		class_1735 slot = (class_1735) this.field_7761.get(index);
		if (slot != null && slot.method_7681()) {
			class_1799 itemstack1 = slot.method_7677();
			itemstack = itemstack1.method_7972();
			if (index < 2) {
				if (!this.method_7616(itemstack1, 2, this.field_7761.size(), true))
					return class_1799.field_8037;
				slot.method_7670(itemstack1, itemstack);
			} else if (!this.method_7616(itemstack1, 0, 2, false)) {
				if (index < 2 + 27) {
					if (!this.method_7616(itemstack1, 2 + 27, this.field_7761.size(), true))
						return class_1799.field_8037;
				} else {
					if (!this.method_7616(itemstack1, 2, 2 + 27, false))
						return class_1799.field_8037;
				}
				return class_1799.field_8037;
			}
			if (itemstack1.method_7960())
				slot.method_7673(class_1799.field_8037);
			else
				slot.method_7668();
			if (itemstack1.method_7947() == itemstack.method_7947())
				return class_1799.field_8037;
			slot.method_7667(player, itemstack1);
		}
		return itemstack;
	}

	@Override
	public void method_7595(class_1657 playerIn) {
		super.method_7595(playerIn);
	}

	public static void screenInit() {
	}
}
