
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.creativecore.block.entity.FanBlockEntity;
import net.mcreator.creativecore.block.entity.CrusherBlockEntity;
import net.mcreator.creativecore.block.entity.CoalgeneratorBlockEntity;
import net.mcreator.creativecore.block.entity.Coalgenerator1BlockEntity;
import net.mcreator.creativecore.block.entity.BatteryblockBlockEntity;
import net.mcreator.creativecore.CreativeWorldMod;

public class CreativeWorldModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES,
			CreativeWorldMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> COALGENERATOR = register("coalgenerator", CreativeWorldModBlocks.COALGENERATOR,
			CoalgeneratorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CRUSHER = register("crusher", CreativeWorldModBlocks.CRUSHER, CrusherBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COALGENERATOR_1 = register("coalgenerator_1", CreativeWorldModBlocks.COALGENERATOR_1,
			Coalgenerator1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> FAN = register("fan", CreativeWorldModBlocks.FAN, FanBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BATTERYBLOCK = register("batteryblock", CreativeWorldModBlocks.BATTERYBLOCK,
			BatteryblockBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block,
			BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
