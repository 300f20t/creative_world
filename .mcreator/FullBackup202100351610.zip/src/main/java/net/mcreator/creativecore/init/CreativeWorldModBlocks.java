
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.creativecore.block.TinwirewithrubberBlock;
import net.mcreator.creativecore.block.Tinwirewithrubber2Block;
import net.mcreator.creativecore.block.TinwireBlock;
import net.mcreator.creativecore.block.TinOreBlock;
import net.mcreator.creativecore.block.TinBlockBlock;
import net.mcreator.creativecore.block.SolarpanelBlock;
import net.mcreator.creativecore.block.RsinlogwithresinBlock;
import net.mcreator.creativecore.block.ResinWoodBlock;
import net.mcreator.creativecore.block.ResinStairsBlock;
import net.mcreator.creativecore.block.ResinSlabBlock;
import net.mcreator.creativecore.block.ResinPlanksBlock;
import net.mcreator.creativecore.block.ResinLogBlock;
import net.mcreator.creativecore.block.ResinLeavesBlock;
import net.mcreator.creativecore.block.ResinFenceGateBlock;
import net.mcreator.creativecore.block.ResinFenceBlock;
import net.mcreator.creativecore.block.OilBlock;
import net.mcreator.creativecore.block.MachinecaseBlock;
import net.mcreator.creativecore.block.GasBlock;
import net.mcreator.creativecore.block.FanBlock;
import net.mcreator.creativecore.block.CrusherBlock;
import net.mcreator.creativecore.block.CoalgeneratorBlock;
import net.mcreator.creativecore.block.Coalgenerator1Block;
import net.mcreator.creativecore.block.BatteryblockBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CreativeWorldModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block MACHINECASE = register(new MachinecaseBlock());
	public static final Block COALGENERATOR = register(new CoalgeneratorBlock());
	public static final Block CRUSHER = register(new CrusherBlock());
	public static final Block TIN_ORE = register(new TinOreBlock());
	public static final Block TIN_BLOCK = register(new TinBlockBlock());
	public static final Block RESIN_WOOD = register(new ResinWoodBlock());
	public static final Block RESIN_LOG = register(new ResinLogBlock());
	public static final Block RSINLOGWITHRESIN = register(new RsinlogwithresinBlock());
	public static final Block RESIN_PLANKS = register(new ResinPlanksBlock());
	public static final Block RESIN_LEAVES = register(new ResinLeavesBlock());
	public static final Block RESIN_STAIRS = register(new ResinStairsBlock());
	public static final Block RESIN_SLAB = register(new ResinSlabBlock());
	public static final Block RESIN_FENCE = register(new ResinFenceBlock());
	public static final Block RESIN_FENCE_GATE = register(new ResinFenceGateBlock());
	public static final Block COALGENERATOR_1 = register(new Coalgenerator1Block());
	public static final Block SOLARPANEL = register(new SolarpanelBlock());
	public static final Block TINWIRE = register(new TinwireBlock());
	public static final Block TINWIREWITHRUBBER = register(new TinwirewithrubberBlock());
	public static final Block OIL = register(new OilBlock());
	public static final Block GAS = register(new GasBlock());
	public static final Block TINWIREWITHRUBBER_2 = register(new Tinwirewithrubber2Block());
	public static final Block FAN = register(new FanBlock());
	public static final Block BATTERYBLOCK = register(new BatteryblockBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			TinwireBlock.registerRenderLayer();
			TinwirewithrubberBlock.registerRenderLayer();
			Tinwirewithrubber2Block.registerRenderLayer();
		}
	}
}
