
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativeworld.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.creativeworld.item.WirecuttersItem;
import net.mcreator.creativeworld.item.WashedcrushedtinoreItem;
import net.mcreator.creativeworld.item.WashedcrushedironoreItem;
import net.mcreator.creativeworld.item.WashedcrushedcopperoreItem;
import net.mcreator.creativeworld.item.TitanplateItem;
import net.mcreator.creativeworld.item.TitanSwordItem;
import net.mcreator.creativeworld.item.TitanShovelItem;
import net.mcreator.creativeworld.item.TitanPickaxeItem;
import net.mcreator.creativeworld.item.TitanIngotItem;
import net.mcreator.creativeworld.item.TitanHoeItem;
import net.mcreator.creativeworld.item.TitanAxeItem;
import net.mcreator.creativeworld.item.TitanArmorItem;
import net.mcreator.creativeworld.item.TinplateItem;
import net.mcreator.creativeworld.item.TinnuggetItem;
import net.mcreator.creativeworld.item.TincoverItem;
import net.mcreator.creativeworld.item.TinSwordItem;
import net.mcreator.creativeworld.item.TinShovelItem;
import net.mcreator.creativeworld.item.TinPickaxeItem;
import net.mcreator.creativeworld.item.TinIngotItem;
import net.mcreator.creativeworld.item.TinHoeItem;
import net.mcreator.creativeworld.item.TinAxeItem;
import net.mcreator.creativeworld.item.TinArmorItem;
import net.mcreator.creativeworld.item.ThecoreoftheformationItem;
import net.mcreator.creativeworld.item.ThecoreofmatterItem;
import net.mcreator.creativeworld.item.ThecoreofinvulnerabilityItem;
import net.mcreator.creativeworld.item.TapItem;
import net.mcreator.creativeworld.item.SdfghnItem;
import net.mcreator.creativeworld.item.RubberItem;
import net.mcreator.creativeworld.item.RawtinItem;
import net.mcreator.creativeworld.item.ParticlebinderItem;
import net.mcreator.creativeworld.item.OilItem;
import net.mcreator.creativeworld.item.LatexItem;
import net.mcreator.creativeworld.item.KeycardItem;
import net.mcreator.creativeworld.item.IronwrenchItem;
import net.mcreator.creativeworld.item.IronplateItem;
import net.mcreator.creativeworld.item.IronhammerItem;
import net.mcreator.creativeworld.item.GasItem;
import net.mcreator.creativeworld.item.EnergydetectorItem;
import net.mcreator.creativeworld.item.EndlesswatersourceItem;
import net.mcreator.creativeworld.item.ElectricjetpackItem;
import net.mcreator.creativeworld.item.ElectricalcircuitItem;
import net.mcreator.creativeworld.item.DrillItem;
import net.mcreator.creativeworld.item.CrushedtinoreItem;
import net.mcreator.creativeworld.item.CrushedironoreItem;
import net.mcreator.creativeworld.item.CrushedcopperoreItem;
import net.mcreator.creativeworld.item.CreativiumnuggetItem;
import net.mcreator.creativeworld.item.CreativiumSwordItem;
import net.mcreator.creativeworld.item.CreativiumShovelItem;
import net.mcreator.creativeworld.item.CreativiumPickaxeItem;
import net.mcreator.creativeworld.item.CreativiumIngotItem;
import net.mcreator.creativeworld.item.CreativiumHoeItem;
import net.mcreator.creativeworld.item.CreativiumAxeItem;
import net.mcreator.creativeworld.item.CreativiumArmorItem;
import net.mcreator.creativeworld.item.CreativemodItem;
import net.mcreator.creativeworld.item.CreativedrillItem;
import net.mcreator.creativeworld.item.CreatingcoreItem;
import net.mcreator.creativeworld.item.CopperplateItem;
import net.mcreator.creativeworld.item.CoppernuggetItem;
import net.mcreator.creativeworld.item.CopperSwordItem;
import net.mcreator.creativeworld.item.CopperShovelItem;
import net.mcreator.creativeworld.item.CopperPickaxeItem;
import net.mcreator.creativeworld.item.CopperHoeItem;
import net.mcreator.creativeworld.item.CopperAxeItem;
import net.mcreator.creativeworld.item.CopperArmorItem;
import net.mcreator.creativeworld.item.CompositeplateItem;
import net.mcreator.creativeworld.item.Composite_plate_toolSwordItem;
import net.mcreator.creativeworld.item.Composite_plate_toolShovelItem;
import net.mcreator.creativeworld.item.Composite_plate_toolPickaxeItem;
import net.mcreator.creativeworld.item.Composite_plate_toolHoeItem;
import net.mcreator.creativeworld.item.Composite_plate_toolAxeItem;
import net.mcreator.creativeworld.item.Composite_plate_armorArmorItem;
import net.mcreator.creativeworld.item.CoaldustItem;
import net.mcreator.creativeworld.item.CarbonplateItem;
import net.mcreator.creativeworld.item.BronzeplateItem;
import net.mcreator.creativeworld.item.BronzedustItem;
import net.mcreator.creativeworld.item.BronzeSwordItem;
import net.mcreator.creativeworld.item.BronzeShovelItem;
import net.mcreator.creativeworld.item.BronzePickaxeItem;
import net.mcreator.creativeworld.item.BronzeIngotItem;
import net.mcreator.creativeworld.item.BronzeHoeItem;
import net.mcreator.creativeworld.item.BronzeAxeItem;
import net.mcreator.creativeworld.item.BronzeArmorItem;
import net.mcreator.creativeworld.item.BedrockbreackerItem;
import net.mcreator.creativeworld.item.BatteryItem;
import net.mcreator.creativeworld.item.Battery5Item;
import net.mcreator.creativeworld.item.Battery4Item;
import net.mcreator.creativeworld.item.Battery3Item;
import net.mcreator.creativeworld.item.Battery2Item;
import net.mcreator.creativeworld.item.Battery1Item;
import net.mcreator.creativeworld.item.Alargebucketofwater9Item;
import net.mcreator.creativeworld.item.Alargebucketofwater8Item;
import net.mcreator.creativeworld.item.Alargebucketofwater7Item;
import net.mcreator.creativeworld.item.Alargebucketofwater6Item;
import net.mcreator.creativeworld.item.Alargebucketofwater5Item;
import net.mcreator.creativeworld.item.Alargebucketofwater4Item;
import net.mcreator.creativeworld.item.Alargebucketofwater3Item;
import net.mcreator.creativeworld.item.Alargebucketofwater2Item;
import net.mcreator.creativeworld.item.Alargebucketofwater1Item;
import net.mcreator.creativeworld.item.AlargebucketItem;
import net.mcreator.creativeworld.item.AdvancedelectricjetpackItem;
import net.mcreator.creativeworld.item.AdvanceddrillItem;
import net.mcreator.creativeworld.item.AccumulatiumnuggetItem;
import net.mcreator.creativeworld.item.AccumulatiumSwordItem;
import net.mcreator.creativeworld.item.AccumulatiumShovelItem;
import net.mcreator.creativeworld.item.AccumulatiumPickaxeItem;
import net.mcreator.creativeworld.item.AccumulatiumIngotItem;
import net.mcreator.creativeworld.item.AccumulatiumHoeItem;
import net.mcreator.creativeworld.item.AccumulatiumAxeItem;
import net.mcreator.creativeworld.item.AccumulatiumArmorItem;
import net.mcreator.creativeworld.CreativeWorldMod;

public class CreativeWorldModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CreativeWorldMod.MODID);
	public static final RegistryObject<Item> ENDLESSWATERSOURCE = REGISTRY.register("endlesswatersource", () -> new EndlesswatersourceItem());
	public static final RegistryObject<Item> ALARGEBUCKET = REGISTRY.register("alargebucket", () -> new AlargebucketItem());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_9 = REGISTRY.register("alargebucketofwater_9", () -> new Alargebucketofwater9Item());
	public static final RegistryObject<Item> GAS_BUCKET = REGISTRY.register("gas_bucket", () -> new GasItem());
	public static final RegistryObject<Item> OIL_BUCKET = REGISTRY.register("oil_bucket", () -> new OilItem());
	public static final RegistryObject<Item> RUBBER = REGISTRY.register("rubber", () -> new RubberItem());
	public static final RegistryObject<Item> LATEX = REGISTRY.register("latex", () -> new LatexItem());
	public static final RegistryObject<Item> COALDUST = REGISTRY.register("coaldust", () -> new CoaldustItem());
	public static final RegistryObject<Item> BRONZEDUST = REGISTRY.register("bronzedust", () -> new BronzedustItem());
	public static final RegistryObject<Item> CRUSHEDTINORE = REGISTRY.register("crushedtinore", () -> new CrushedtinoreItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDTINORE = REGISTRY.register("washedcrushedtinore", () -> new WashedcrushedtinoreItem());
	public static final RegistryObject<Item> CRUSHEDCOPPERORE = REGISTRY.register("crushedcopperore", () -> new CrushedcopperoreItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDCOPPERORE = REGISTRY.register("washedcrushedcopperore",
			() -> new WashedcrushedcopperoreItem());
	public static final RegistryObject<Item> CRUSHEDIRONORE = REGISTRY.register("crushedironore", () -> new CrushedironoreItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDIRONORE = REGISTRY.register("washedcrushedironore", () -> new WashedcrushedironoreItem());
	public static final RegistryObject<Item> RAWTIN = REGISTRY.register("rawtin", () -> new RawtinItem());
	public static final RegistryObject<Item> TIN_INGOT = REGISTRY.register("tin_ingot", () -> new TinIngotItem());
	public static final RegistryObject<Item> BRONZE_INGOT = REGISTRY.register("bronze_ingot", () -> new BronzeIngotItem());
	public static final RegistryObject<Item> TITAN_INGOT = REGISTRY.register("titan_ingot", () -> new TitanIngotItem());
	public static final RegistryObject<Item> ACCUMULATIUM_INGOT = REGISTRY.register("accumulatium_ingot", () -> new AccumulatiumIngotItem());
	public static final RegistryObject<Item> CREATIVIUM_INGOT = REGISTRY.register("creativium_ingot", () -> new CreativiumIngotItem());
	public static final RegistryObject<Item> TINNUGGET = REGISTRY.register("tinnugget", () -> new TinnuggetItem());
	public static final RegistryObject<Item> COPPERNUGGET = REGISTRY.register("coppernugget", () -> new CoppernuggetItem());
	public static final RegistryObject<Item> ACCUMULATIUMNUGGET = REGISTRY.register("accumulatiumnugget", () -> new AccumulatiumnuggetItem());
	public static final RegistryObject<Item> CREATIVIUMNUGGET = REGISTRY.register("creativiumnugget", () -> new CreativiumnuggetItem());
	public static final RegistryObject<Item> TINPLATE = REGISTRY.register("tinplate", () -> new TinplateItem());
	public static final RegistryObject<Item> COPPERPLATE = REGISTRY.register("copperplate", () -> new CopperplateItem());
	public static final RegistryObject<Item> IRONPLATE = REGISTRY.register("ironplate", () -> new IronplateItem());
	public static final RegistryObject<Item> COMPOSITEPLATE = REGISTRY.register("compositeplate", () -> new CompositeplateItem());
	public static final RegistryObject<Item> CARBONPLATE = REGISTRY.register("carbonplate", () -> new CarbonplateItem());
	public static final RegistryObject<Item> BRONZEPLATE = REGISTRY.register("bronzeplate", () -> new BronzeplateItem());
	public static final RegistryObject<Item> TITANPLATE = REGISTRY.register("titanplate", () -> new TitanplateItem());
	public static final RegistryObject<Item> TINCOVER = REGISTRY.register("tincover", () -> new TincoverItem());
	public static final RegistryObject<Item> SDFGHN = REGISTRY.register("sdfghn", () -> new SdfghnItem());
	public static final RegistryObject<Item> THECOREOFMATTER = REGISTRY.register("thecoreofmatter", () -> new ThecoreofmatterItem());
	public static final RegistryObject<Item> THECOREOFTHEFORMATION = REGISTRY.register("thecoreoftheformation",
			() -> new ThecoreoftheformationItem());
	public static final RegistryObject<Item> CREATINGCORE = REGISTRY.register("creatingcore", () -> new CreatingcoreItem());
	public static final RegistryObject<Item> BATTERY = REGISTRY.register("battery", () -> new BatteryItem());
	public static final RegistryObject<Item> BATTERY_5 = REGISTRY.register("battery_5", () -> new Battery5Item());
	public static final RegistryObject<Item> ELECTRICALCIRCUIT = REGISTRY.register("electricalcircuit", () -> new ElectricalcircuitItem());
	public static final RegistryObject<Item> THECOREOFINVULNERABILITY = REGISTRY.register("thecoreofinvulnerability",
			() -> new ThecoreofinvulnerabilityItem());
	public static final RegistryObject<Item> CREATIVEMOD = REGISTRY.register("creativemod", () -> new CreativemodItem());
	public static final RegistryObject<Item> TIN_PICKAXE = REGISTRY.register("tin_pickaxe", () -> new TinPickaxeItem());
	public static final RegistryObject<Item> TIN_AXE = REGISTRY.register("tin_axe", () -> new TinAxeItem());
	public static final RegistryObject<Item> TIN_SHOVEL = REGISTRY.register("tin_shovel", () -> new TinShovelItem());
	public static final RegistryObject<Item> TIN_HOE = REGISTRY.register("tin_hoe", () -> new TinHoeItem());
	public static final RegistryObject<Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final RegistryObject<Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final RegistryObject<Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final RegistryObject<Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final RegistryObject<Item> BRONZE_PICKAXE = REGISTRY.register("bronze_pickaxe", () -> new BronzePickaxeItem());
	public static final RegistryObject<Item> BRONZE_AXE = REGISTRY.register("bronze_axe", () -> new BronzeAxeItem());
	public static final RegistryObject<Item> BRONZE_SHOVEL = REGISTRY.register("bronze_shovel", () -> new BronzeShovelItem());
	public static final RegistryObject<Item> BRONZE_HOE = REGISTRY.register("bronze_hoe", () -> new BronzeHoeItem());
	public static final RegistryObject<Item> CREATIVIUM_PICKAXE = REGISTRY.register("creativium_pickaxe", () -> new CreativiumPickaxeItem());
	public static final RegistryObject<Item> CREATIVIUM_AXE = REGISTRY.register("creativium_axe", () -> new CreativiumAxeItem());
	public static final RegistryObject<Item> CREATIVIUM_SHOVEL = REGISTRY.register("creativium_shovel", () -> new CreativiumShovelItem());
	public static final RegistryObject<Item> CREATIVIUM_HOE = REGISTRY.register("creativium_hoe", () -> new CreativiumHoeItem());
	public static final RegistryObject<Item> ACCUMULATIUM_PICKAXE = REGISTRY.register("accumulatium_pickaxe", () -> new AccumulatiumPickaxeItem());
	public static final RegistryObject<Item> ACCUMULATIUM_AXE = REGISTRY.register("accumulatium_axe", () -> new AccumulatiumAxeItem());
	public static final RegistryObject<Item> ACCUMULATIUM_SHOVEL = REGISTRY.register("accumulatium_shovel", () -> new AccumulatiumShovelItem());
	public static final RegistryObject<Item> ACCUMULATIUM_HOE = REGISTRY.register("accumulatium_hoe", () -> new AccumulatiumHoeItem());
	public static final RegistryObject<Item> TITAN_PICKAXE = REGISTRY.register("titan_pickaxe", () -> new TitanPickaxeItem());
	public static final RegistryObject<Item> TITAN_AXE = REGISTRY.register("titan_axe", () -> new TitanAxeItem());
	public static final RegistryObject<Item> TITAN_SHOVEL = REGISTRY.register("titan_shovel", () -> new TitanShovelItem());
	public static final RegistryObject<Item> TITAN_HOE = REGISTRY.register("titan_hoe", () -> new TitanHoeItem());
	public static final RegistryObject<Item> COMPOSITE_PLATE_TOOL_PICKAXE = REGISTRY.register("composite_plate_tool_pickaxe",
			() -> new Composite_plate_toolPickaxeItem());
	public static final RegistryObject<Item> COMPOSITE_PLATE_TOOL_AXE = REGISTRY.register("composite_plate_tool_axe",
			() -> new Composite_plate_toolAxeItem());
	public static final RegistryObject<Item> COMPOSITE_PLATE_TOOL_SHOVEL = REGISTRY.register("composite_plate_tool_shovel",
			() -> new Composite_plate_toolShovelItem());
	public static final RegistryObject<Item> COMPOSITE_PLATE_TOOL_HOE = REGISTRY.register("composite_plate_tool_hoe",
			() -> new Composite_plate_toolHoeItem());
	public static final RegistryObject<Item> BEDROCKBREACKER = REGISTRY.register("bedrockbreacker", () -> new BedrockbreackerItem());
	public static final RegistryObject<Item> DRILL = REGISTRY.register("drill", () -> new DrillItem());
	public static final RegistryObject<Item> ADVANCEDDRILL = REGISTRY.register("advanceddrill", () -> new AdvanceddrillItem());
	public static final RegistryObject<Item> CREATIVEDRILL = REGISTRY.register("creativedrill", () -> new CreativedrillItem());
	public static final RegistryObject<Item> IRONHAMMER = REGISTRY.register("ironhammer", () -> new IronhammerItem());
	public static final RegistryObject<Item> IRONWRENCH = REGISTRY.register("ironwrench", () -> new IronwrenchItem());
	public static final RegistryObject<Item> WIRECUTTERS = REGISTRY.register("wirecutters", () -> new WirecuttersItem());
	public static final RegistryObject<Item> TAP = REGISTRY.register("tap", () -> new TapItem());
	public static final RegistryObject<Item> ENERGYDETECTOR = REGISTRY.register("energydetector", () -> new EnergydetectorItem());
	public static final RegistryObject<Item> PARTICLEBINDER = REGISTRY.register("particlebinder", () -> new ParticlebinderItem());
	public static final RegistryObject<Item> KEYCARD = REGISTRY.register("keycard", () -> new KeycardItem());
	public static final RegistryObject<Item> TIN_ORE = block(CreativeWorldModBlocks.TIN_ORE, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TITAN_ORE = block(CreativeWorldModBlocks.TITAN_ORE, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> ACCUMULATIUM_ORE = block(CreativeWorldModBlocks.ACCUMULATIUM_ORE,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> CREATIVIUM_ORE = block(CreativeWorldModBlocks.CREATIVIUM_ORE,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TIN_BLOCK = block(CreativeWorldModBlocks.TIN_BLOCK, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> BRONZE_BLOCK = block(CreativeWorldModBlocks.BRONZE_BLOCK, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> ACCUMULATIUM_BLOCK = block(CreativeWorldModBlocks.ACCUMULATIUM_BLOCK,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> CREATIVIUM_BLOCK = block(CreativeWorldModBlocks.CREATIVIUM_BLOCK,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_LOG = block(CreativeWorldModBlocks.RESIN_LOG, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RSINLOGWITHRESIN = block(CreativeWorldModBlocks.RSINLOGWITHRESIN,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_WOOD = block(CreativeWorldModBlocks.RESIN_WOOD, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_PLANKS = block(CreativeWorldModBlocks.RESIN_PLANKS, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_STAIRS = block(CreativeWorldModBlocks.RESIN_STAIRS, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_SLAB = block(CreativeWorldModBlocks.RESIN_SLAB, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_LEAVES = block(CreativeWorldModBlocks.RESIN_LEAVES, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_FENCE = block(CreativeWorldModBlocks.RESIN_FENCE, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> RESIN_FENCE_GATE = block(CreativeWorldModBlocks.RESIN_FENCE_GATE,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TINWIRE = block(CreativeWorldModBlocks.TINWIRE, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER = block(CreativeWorldModBlocks.TINWIREWITHRUBBER,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_2 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_2, null);
	public static final RegistryObject<Item> TITAN_BLOCK = block(CreativeWorldModBlocks.TITAN_BLOCK, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> MACHINECASE = block(CreativeWorldModBlocks.MACHINECASE, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> COALGENERATOR = block(CreativeWorldModBlocks.COALGENERATOR,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> CRUSHER = block(CreativeWorldModBlocks.CRUSHER, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> FAN = block(CreativeWorldModBlocks.FAN, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> BATTERYBLOCK = block(CreativeWorldModBlocks.BATTERYBLOCK, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> SOLARPANEL = block(CreativeWorldModBlocks.SOLARPANEL, CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> ADVENCEDMACHINECASE = block(CreativeWorldModBlocks.ADVENCEDMACHINECASE,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> ADVENCEDSOLARPANEL = block(CreativeWorldModBlocks.ADVENCEDSOLARPANEL,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> INFINITYENERGY = block(CreativeWorldModBlocks.INFINITYENERGY,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> QUANTUMTELEPORTERBLOCK = block(CreativeWorldModBlocks.QUANTUMTELEPORTERBLOCK,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> QUANTUMTELEPORTERBLOCK_2 = block(CreativeWorldModBlocks.QUANTUMTELEPORTERBLOCK_2,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> STATIONARYPARTICLEBINDER = block(CreativeWorldModBlocks.STATIONARYPARTICLEBINDER,
			CreativeWorldModTabs.TAB_CREATIVEWORLDBLOCKS);
	public static final RegistryObject<Item> TIN_SWORD = REGISTRY.register("tin_sword", () -> new TinSwordItem());
	public static final RegistryObject<Item> TIN_ARMOR_HELMET = REGISTRY.register("tin_armor_helmet", () -> new TinArmorItem.Helmet());
	public static final RegistryObject<Item> TIN_ARMOR_CHESTPLATE = REGISTRY.register("tin_armor_chestplate", () -> new TinArmorItem.Chestplate());
	public static final RegistryObject<Item> TIN_ARMOR_LEGGINGS = REGISTRY.register("tin_armor_leggings", () -> new TinArmorItem.Leggings());
	public static final RegistryObject<Item> TIN_ARMOR_BOOTS = REGISTRY.register("tin_armor_boots", () -> new TinArmorItem.Boots());
	public static final RegistryObject<Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final RegistryObject<Item> COPPER_ARMOR_HELMET = REGISTRY.register("copper_armor_helmet", () -> new CopperArmorItem.Helmet());
	public static final RegistryObject<Item> COPPER_ARMOR_CHESTPLATE = REGISTRY.register("copper_armor_chestplate",
			() -> new CopperArmorItem.Chestplate());
	public static final RegistryObject<Item> COPPER_ARMOR_LEGGINGS = REGISTRY.register("copper_armor_leggings", () -> new CopperArmorItem.Leggings());
	public static final RegistryObject<Item> COPPER_ARMOR_BOOTS = REGISTRY.register("copper_armor_boots", () -> new CopperArmorItem.Boots());
	public static final RegistryObject<Item> BRONZE_SWORD = REGISTRY.register("bronze_sword", () -> new BronzeSwordItem());
	public static final RegistryObject<Item> BRONZE_ARMOR_HELMET = REGISTRY.register("bronze_armor_helmet", () -> new BronzeArmorItem.Helmet());
	public static final RegistryObject<Item> BRONZE_ARMOR_CHESTPLATE = REGISTRY.register("bronze_armor_chestplate",
			() -> new BronzeArmorItem.Chestplate());
	public static final RegistryObject<Item> BRONZE_ARMOR_LEGGINGS = REGISTRY.register("bronze_armor_leggings", () -> new BronzeArmorItem.Leggings());
	public static final RegistryObject<Item> BRONZE_ARMOR_BOOTS = REGISTRY.register("bronze_armor_boots", () -> new BronzeArmorItem.Boots());
	public static final RegistryObject<Item> COMPOSITE_PLATE_TOOL_SWORD = REGISTRY.register("composite_plate_tool_sword",
			() -> new Composite_plate_toolSwordItem());
	public static final RegistryObject<Item> COMPOSITE_PLATE_ARMOR_ARMOR_HELMET = REGISTRY.register("composite_plate_armor_armor_helmet",
			() -> new Composite_plate_armorArmorItem.Helmet());
	public static final RegistryObject<Item> COMPOSITE_PLATE_ARMOR_ARMOR_CHESTPLATE = REGISTRY.register("composite_plate_armor_armor_chestplate",
			() -> new Composite_plate_armorArmorItem.Chestplate());
	public static final RegistryObject<Item> COMPOSITE_PLATE_ARMOR_ARMOR_LEGGINGS = REGISTRY.register("composite_plate_armor_armor_leggings",
			() -> new Composite_plate_armorArmorItem.Leggings());
	public static final RegistryObject<Item> COMPOSITE_PLATE_ARMOR_ARMOR_BOOTS = REGISTRY.register("composite_plate_armor_armor_boots",
			() -> new Composite_plate_armorArmorItem.Boots());
	public static final RegistryObject<Item> TITAN_SWORD = REGISTRY.register("titan_sword", () -> new TitanSwordItem());
	public static final RegistryObject<Item> TITAN_ARMOR_HELMET = REGISTRY.register("titan_armor_helmet", () -> new TitanArmorItem.Helmet());
	public static final RegistryObject<Item> TITAN_ARMOR_CHESTPLATE = REGISTRY.register("titan_armor_chestplate",
			() -> new TitanArmorItem.Chestplate());
	public static final RegistryObject<Item> TITAN_ARMOR_LEGGINGS = REGISTRY.register("titan_armor_leggings", () -> new TitanArmorItem.Leggings());
	public static final RegistryObject<Item> TITAN_ARMOR_BOOTS = REGISTRY.register("titan_armor_boots", () -> new TitanArmorItem.Boots());
	public static final RegistryObject<Item> ACCUMULATIUM_SWORD = REGISTRY.register("accumulatium_sword", () -> new AccumulatiumSwordItem());
	public static final RegistryObject<Item> ACCUMULATIUM_ARMOR_HELMET = REGISTRY.register("accumulatium_armor_helmet",
			() -> new AccumulatiumArmorItem.Helmet());
	public static final RegistryObject<Item> ACCUMULATIUM_ARMOR_CHESTPLATE = REGISTRY.register("accumulatium_armor_chestplate",
			() -> new AccumulatiumArmorItem.Chestplate());
	public static final RegistryObject<Item> ACCUMULATIUM_ARMOR_LEGGINGS = REGISTRY.register("accumulatium_armor_leggings",
			() -> new AccumulatiumArmorItem.Leggings());
	public static final RegistryObject<Item> ACCUMULATIUM_ARMOR_BOOTS = REGISTRY.register("accumulatium_armor_boots",
			() -> new AccumulatiumArmorItem.Boots());
	public static final RegistryObject<Item> CREATIVIUM_SWORD = REGISTRY.register("creativium_sword", () -> new CreativiumSwordItem());
	public static final RegistryObject<Item> CREATIVIUM_ARMOR_HELMET = REGISTRY.register("creativium_armor_helmet",
			() -> new CreativiumArmorItem.Helmet());
	public static final RegistryObject<Item> CREATIVIUM_ARMOR_CHESTPLATE = REGISTRY.register("creativium_armor_chestplate",
			() -> new CreativiumArmorItem.Chestplate());
	public static final RegistryObject<Item> CREATIVIUM_ARMOR_LEGGINGS = REGISTRY.register("creativium_armor_leggings",
			() -> new CreativiumArmorItem.Leggings());
	public static final RegistryObject<Item> CREATIVIUM_ARMOR_BOOTS = REGISTRY.register("creativium_armor_boots",
			() -> new CreativiumArmorItem.Boots());
	public static final RegistryObject<Item> ELECTRICJETPACK_CHESTPLATE = REGISTRY.register("electricjetpack_chestplate",
			() -> new ElectricjetpackItem.Chestplate());
	public static final RegistryObject<Item> ADVANCEDELECTRICJETPACK_CHESTPLATE = REGISTRY.register("advancedelectricjetpack_chestplate",
			() -> new AdvancedelectricjetpackItem.Chestplate());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_1 = REGISTRY.register("alargebucketofwater_1", () -> new Alargebucketofwater1Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_2 = REGISTRY.register("alargebucketofwater_2", () -> new Alargebucketofwater2Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_3 = REGISTRY.register("alargebucketofwater_3", () -> new Alargebucketofwater3Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_4 = REGISTRY.register("alargebucketofwater_4", () -> new Alargebucketofwater4Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_5 = REGISTRY.register("alargebucketofwater_5", () -> new Alargebucketofwater5Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_6 = REGISTRY.register("alargebucketofwater_6", () -> new Alargebucketofwater6Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_7 = REGISTRY.register("alargebucketofwater_7", () -> new Alargebucketofwater7Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_8 = REGISTRY.register("alargebucketofwater_8", () -> new Alargebucketofwater8Item());
	public static final RegistryObject<Item> COALGENERATOR_1 = block(CreativeWorldModBlocks.COALGENERATOR_1, null);
	public static final RegistryObject<Item> BATTERY_1 = REGISTRY.register("battery_1", () -> new Battery1Item());
	public static final RegistryObject<Item> BATTERY_2 = REGISTRY.register("battery_2", () -> new Battery2Item());
	public static final RegistryObject<Item> BATTERY_3 = REGISTRY.register("battery_3", () -> new Battery3Item());
	public static final RegistryObject<Item> BATTERY_4 = REGISTRY.register("battery_4", () -> new Battery4Item());
	public static final RegistryObject<Item> TINWIREWITHRUBBER_3 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_3, null);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_4 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_4,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_5 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_5,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_6 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_6,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_7 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_7,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_8 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_8,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_9 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_9,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_10 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_10,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_11 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_11,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_12 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_12,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_13 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_13,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_14 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_14,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);
	public static final RegistryObject<Item> TINWIREWITHRUBBER_15 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_15,
			CreativeWorldModTabs.TAB_CREATIVEWORLDITEMS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
