
package net.mcreator.creativecore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class Battery1Item extends Item {
	public Battery1Item() {
		super(new Item.Properties().tab(null).durability(1000).rarity(Rarity.COMMON));
		setRegistryName("battery_1");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
