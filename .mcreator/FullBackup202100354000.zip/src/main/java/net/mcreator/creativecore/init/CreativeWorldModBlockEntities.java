
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.creativecore.block.entity.FanBlockEntity;
import net.mcreator.creativecore.block.entity.CrusherBlockEntity;
import net.mcreator.creativecore.block.entity.CoalgeneratorBlockEntity;
import net.mcreator.creativecore.block.entity.Coalgenerator1BlockEntity;
import net.mcreator.creativecore.block.entity.BatteryblockBlockEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CreativeWorldModBlockEntities {
	private static final List<BlockEntityType<?>> REGISTRY = new ArrayList<>();
	public static final BlockEntityType<?> COALGENERATOR = register("creative_world:coalgenerator", CreativeWorldModBlocks.COALGENERATOR,
			CoalgeneratorBlockEntity::new);
	public static final BlockEntityType<?> CRUSHER = register("creative_world:crusher", CreativeWorldModBlocks.CRUSHER, CrusherBlockEntity::new);
	public static final BlockEntityType<?> COALGENERATOR_1 = register("creative_world:coalgenerator_1", CreativeWorldModBlocks.COALGENERATOR_1,
			Coalgenerator1BlockEntity::new);
	public static final BlockEntityType<?> FAN = register("creative_world:fan", CreativeWorldModBlocks.FAN, FanBlockEntity::new);
	public static final BlockEntityType<?> BATTERYBLOCK = register("creative_world:batteryblock", CreativeWorldModBlocks.BATTERYBLOCK,
			BatteryblockBlockEntity::new);

	private static BlockEntityType<?> register(String registryname, Block block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		BlockEntityType<?> blockEntityType = BlockEntityType.Builder.of(supplier, block).build(null).setRegistryName(registryname);
		REGISTRY.add(blockEntityType);
		return blockEntityType;
	}

	@SubscribeEvent
	public static void registerTileEntity(RegistryEvent.Register<BlockEntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new BlockEntityType[0]));
	}
}
