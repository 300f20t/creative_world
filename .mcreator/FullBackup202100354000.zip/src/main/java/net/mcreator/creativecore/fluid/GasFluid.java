
package net.mcreator.creativecore.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.creativecore.init.CreativeWorldModItems;
import net.mcreator.creativecore.init.CreativeWorldModFluids;
import net.mcreator.creativecore.init.CreativeWorldModBlocks;

public abstract class GasFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> CreativeWorldModFluids.GAS,
			() -> CreativeWorldModFluids.FLOWING_GAS,
			FluidAttributes.builder(new ResourceLocation("creative_world:blocks/sapro"), new ResourceLocation("creative_world:blocks/apr"))

					.density(100).viscosity(53)

					.gaseous()

	).explosionResistance(100f)

			.bucket(() -> CreativeWorldModItems.GAS_BUCKET).block(() -> (LiquidBlock) CreativeWorldModBlocks.GAS);

	private GasFluid() {
		super(PROPERTIES);
	}

	public static class Source extends GasFluid {
		public Source() {
			super();
			setRegistryName("gas");
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends GasFluid {
		public Flowing() {
			super();
			setRegistryName("flowing_gas");
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
