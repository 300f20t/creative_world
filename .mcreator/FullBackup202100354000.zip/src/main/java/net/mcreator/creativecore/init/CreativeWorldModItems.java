
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.creativecore.item.WirecuttersItem;
import net.mcreator.creativecore.item.WashedcrushedtinoreItem;
import net.mcreator.creativecore.item.WashedcrushedironoreItem;
import net.mcreator.creativecore.item.WashedcrushedcopperoreItem;
import net.mcreator.creativecore.item.TinplateItem;
import net.mcreator.creativecore.item.TinnuggetItem;
import net.mcreator.creativecore.item.TincoverItem;
import net.mcreator.creativecore.item.TinSwordItem;
import net.mcreator.creativecore.item.TinShovelItem;
import net.mcreator.creativecore.item.TinPickaxeItem;
import net.mcreator.creativecore.item.TinIngotItem;
import net.mcreator.creativecore.item.TinHoeItem;
import net.mcreator.creativecore.item.TinAxeItem;
import net.mcreator.creativecore.item.TinArmorItem;
import net.mcreator.creativecore.item.ThecoreoftheformationItem;
import net.mcreator.creativecore.item.ThecoreofmatterItem;
import net.mcreator.creativecore.item.TapItem;
import net.mcreator.creativecore.item.SdfghnItem;
import net.mcreator.creativecore.item.RubberItem;
import net.mcreator.creativecore.item.RawtinItem;
import net.mcreator.creativecore.item.OilItem;
import net.mcreator.creativecore.item.LatexItem;
import net.mcreator.creativecore.item.IronwrenchItem;
import net.mcreator.creativecore.item.IronplateItem;
import net.mcreator.creativecore.item.IronhammerItem;
import net.mcreator.creativecore.item.GasItem;
import net.mcreator.creativecore.item.EnergydetectorItem;
import net.mcreator.creativecore.item.EndlesswatersourceItem;
import net.mcreator.creativecore.item.ElectricjetpackItem;
import net.mcreator.creativecore.item.CrushedtinoreItem;
import net.mcreator.creativecore.item.CrushedironoreItem;
import net.mcreator.creativecore.item.CrushedcopperoreItem;
import net.mcreator.creativecore.item.CreativemodItem;
import net.mcreator.creativecore.item.CreatingcoreItem;
import net.mcreator.creativecore.item.CopperplateItem;
import net.mcreator.creativecore.item.CoppernuggetItem;
import net.mcreator.creativecore.item.CopperSwordItem;
import net.mcreator.creativecore.item.CopperShovelItem;
import net.mcreator.creativecore.item.CopperPickaxeItem;
import net.mcreator.creativecore.item.CopperHoeItem;
import net.mcreator.creativecore.item.CopperAxeItem;
import net.mcreator.creativecore.item.CopperArmorItem;
import net.mcreator.creativecore.item.BronzedustItem;
import net.mcreator.creativecore.item.BedrockbreackerItem;
import net.mcreator.creativecore.item.BatteryItem;
import net.mcreator.creativecore.item.Battery5Item;
import net.mcreator.creativecore.item.Battery4Item;
import net.mcreator.creativecore.item.Battery3Item;
import net.mcreator.creativecore.item.Battery2Item;
import net.mcreator.creativecore.item.Battery1Item;
import net.mcreator.creativecore.item.Alargebucketofwater9Item;
import net.mcreator.creativecore.item.Alargebucketofwater8Item;
import net.mcreator.creativecore.item.Alargebucketofwater7Item;
import net.mcreator.creativecore.item.Alargebucketofwater6Item;
import net.mcreator.creativecore.item.Alargebucketofwater5Item;
import net.mcreator.creativecore.item.Alargebucketofwater4Item;
import net.mcreator.creativecore.item.Alargebucketofwater3Item;
import net.mcreator.creativecore.item.Alargebucketofwater2Item;
import net.mcreator.creativecore.item.Alargebucketofwater1Item;
import net.mcreator.creativecore.item.AlargebucketItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CreativeWorldModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item ALARGEBUCKET = register(new AlargebucketItem());
	public static final Item ALARGEBUCKETOFWATER_1 = register(new Alargebucketofwater1Item());
	public static final Item ALARGEBUCKETOFWATER_2 = register(new Alargebucketofwater2Item());
	public static final Item ALARGEBUCKETOFWATER_3 = register(new Alargebucketofwater3Item());
	public static final Item ALARGEBUCKETOFWATER_4 = register(new Alargebucketofwater4Item());
	public static final Item ALARGEBUCKETOFWATER_5 = register(new Alargebucketofwater5Item());
	public static final Item ALARGEBUCKETOFWATER_6 = register(new Alargebucketofwater6Item());
	public static final Item ALARGEBUCKETOFWATER_7 = register(new Alargebucketofwater7Item());
	public static final Item ALARGEBUCKETOFWATER_8 = register(new Alargebucketofwater8Item());
	public static final Item ALARGEBUCKETOFWATER_9 = register(new Alargebucketofwater9Item());
	public static final Item ENDLESSWATERSOURCE = register(new EndlesswatersourceItem());
	public static final Item TIN_INGOT = register(new TinIngotItem());
	public static final Item TINPLATE = register(new TinplateItem());
	public static final Item COPPERPLATE = register(new CopperplateItem());
	public static final Item IRONPLATE = register(new IronplateItem());
	public static final Item TIN_PICKAXE = register(new TinPickaxeItem());
	public static final Item TIN_AXE = register(new TinAxeItem());
	public static final Item TIN_SHOVEL = register(new TinShovelItem());
	public static final Item TIN_HOE = register(new TinHoeItem());
	public static final Item COPPER_PICKAXE = register(new CopperPickaxeItem());
	public static final Item COPPER_AXE = register(new CopperAxeItem());
	public static final Item COPPER_SHOVEL = register(new CopperShovelItem());
	public static final Item COPPER_HOE = register(new CopperHoeItem());
	public static final Item IRONHAMMER = register(new IronhammerItem());
	public static final Item IRONWRENCH = register(new IronwrenchItem());
	public static final Item WIRECUTTERS = register(new WirecuttersItem());
	public static final Item MACHINECASE = register(CreativeWorldModBlocks.MACHINECASE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item COALGENERATOR = register(CreativeWorldModBlocks.COALGENERATOR, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRUSHER = register(CreativeWorldModBlocks.CRUSHER, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item TIN_ORE = register(CreativeWorldModBlocks.TIN_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item TIN_BLOCK = register(CreativeWorldModBlocks.TIN_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_WOOD = register(CreativeWorldModBlocks.RESIN_WOOD, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_LOG = register(CreativeWorldModBlocks.RESIN_LOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RSINLOGWITHRESIN = register(CreativeWorldModBlocks.RSINLOGWITHRESIN, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_PLANKS = register(CreativeWorldModBlocks.RESIN_PLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_LEAVES = register(CreativeWorldModBlocks.RESIN_LEAVES, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_STAIRS = register(CreativeWorldModBlocks.RESIN_STAIRS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_SLAB = register(CreativeWorldModBlocks.RESIN_SLAB, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_FENCE = register(CreativeWorldModBlocks.RESIN_FENCE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RESIN_FENCE_GATE = register(CreativeWorldModBlocks.RESIN_FENCE_GATE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item TIN_SWORD = register(new TinSwordItem());
	public static final Item TIN_ARMOR_HELMET = register(new TinArmorItem.Helmet());
	public static final Item TIN_ARMOR_CHESTPLATE = register(new TinArmorItem.Chestplate());
	public static final Item TIN_ARMOR_LEGGINGS = register(new TinArmorItem.Leggings());
	public static final Item TIN_ARMOR_BOOTS = register(new TinArmorItem.Boots());
	public static final Item COPPER_SWORD = register(new CopperSwordItem());
	public static final Item COPPER_ARMOR_HELMET = register(new CopperArmorItem.Helmet());
	public static final Item COPPER_ARMOR_CHESTPLATE = register(new CopperArmorItem.Chestplate());
	public static final Item COPPER_ARMOR_LEGGINGS = register(new CopperArmorItem.Leggings());
	public static final Item COPPER_ARMOR_BOOTS = register(new CopperArmorItem.Boots());
	public static final Item THECOREOFTHEFORMATION = register(new ThecoreoftheformationItem());
	public static final Item THECOREOFMATTER = register(new ThecoreofmatterItem());
	public static final Item CREATINGCORE = register(new CreatingcoreItem());
	public static final Item BEDROCKBREACKER = register(new BedrockbreackerItem());
	public static final Item COALGENERATOR_1 = register(CreativeWorldModBlocks.COALGENERATOR_1, null);
	public static final Item SOLARPANEL = register(CreativeWorldModBlocks.SOLARPANEL, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRUSHEDIRONORE = register(new CrushedironoreItem());
	public static final Item TINWIRE = register(CreativeWorldModBlocks.TINWIRE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRUSHEDCOPPERORE = register(new CrushedcopperoreItem());
	public static final Item CRUSHEDTINORE = register(new CrushedtinoreItem());
	public static final Item TINNUGGET = register(new TinnuggetItem());
	public static final Item COPPERNUGGET = register(new CoppernuggetItem());
	public static final Item WASHEDCRUSHEDIRONORE = register(new WashedcrushedironoreItem());
	public static final Item WASHEDCRUSHEDCOPPERORE = register(new WashedcrushedcopperoreItem());
	public static final Item WASHEDCRUSHEDTINORE = register(new WashedcrushedtinoreItem());
	public static final Item CREATIVEMOD = register(new CreativemodItem());
	public static final Item SDFGHN = register(new SdfghnItem());
	public static final Item LATEX = register(new LatexItem());
	public static final Item TAP = register(new TapItem());
	public static final Item RUBBER = register(new RubberItem());
	public static final Item TINCOVER = register(new TincoverItem());
	public static final Item BATTERY = register(new BatteryItem());
	public static final Item TINWIREWITHRUBBER = register(CreativeWorldModBlocks.TINWIREWITHRUBBER, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item OIL_BUCKET = register(new OilItem());
	public static final Item GAS_BUCKET = register(new GasItem());
	public static final Item BATTERY_1 = register(new Battery1Item());
	public static final Item BATTERY_2 = register(new Battery2Item());
	public static final Item BATTERY_3 = register(new Battery3Item());
	public static final Item BATTERY_4 = register(new Battery4Item());
	public static final Item BATTERY_5 = register(new Battery5Item());
	public static final Item TINWIREWITHRUBBER_2 = register(CreativeWorldModBlocks.TINWIREWITHRUBBER_2, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item RAWTIN = register(new RawtinItem());
	public static final Item BRONZEDUST = register(new BronzedustItem());
	public static final Item ENERGYDETECTOR = register(new EnergydetectorItem());
	public static final Item FAN = register(CreativeWorldModBlocks.FAN, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item BATTERYBLOCK = register(CreativeWorldModBlocks.BATTERYBLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item ELECTRICJETPACK_CHESTPLATE = register(new ElectricjetpackItem.Chestplate());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
