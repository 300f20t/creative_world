
package net.mcreator.creativecore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class CreatingcoreItem extends Item {
	public CreatingcoreItem() {
		super(new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(64).rarity(Rarity.RARE));
		setRegistryName("creatingcore");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
