
package net.mcreator.creativecore.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class Battery5Item extends Item {
	public Battery5Item() {
		super(new Item.Properties().tab(CreativeModeTab.TAB_MISC).durability(1000).rarity(Rarity.COMMON));
		setRegistryName("battery_5");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
