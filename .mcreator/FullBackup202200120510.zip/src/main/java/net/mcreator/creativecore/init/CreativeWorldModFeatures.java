
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.creativecore.world.features.ores.TinOreFeature;
import net.mcreator.creativecore.world.features.RubbertreeFeature;
import net.mcreator.creativecore.world.features.MediumoilmineFeature;
import net.mcreator.creativecore.world.features.MediumgasmineFeature;
import net.mcreator.creativecore.world.features.LittleoilmineFeature;
import net.mcreator.creativecore.world.features.LittlegasmineFeature;
import net.mcreator.creativecore.CreativeWorldMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class CreativeWorldModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, CreativeWorldMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> TIN_ORE = register("tin_ore", TinOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, TinOreFeature.GENERATE_BIOMES, TinOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> RUBBERTREE = register("rubbertree", RubbertreeFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.SURFACE_STRUCTURES, RubbertreeFeature.GENERATE_BIOMES, RubbertreeFeature::placedFeature));
	public static final RegistryObject<Feature<?>> LITTLEOILMINE = register("littleoilmine", LittleoilmineFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_STRUCTURES, LittleoilmineFeature.GENERATE_BIOMES, LittleoilmineFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MEDIUMOILMINE = register("mediumoilmine", MediumoilmineFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_STRUCTURES, MediumoilmineFeature.GENERATE_BIOMES, MediumoilmineFeature::placedFeature));
	public static final RegistryObject<Feature<?>> LITTLEGASMINE = register("littlegasmine", LittlegasmineFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_STRUCTURES, LittlegasmineFeature.GENERATE_BIOMES, LittlegasmineFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MEDIUMGASMINE = register("mediumgasmine", MediumgasmineFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_STRUCTURES, MediumgasmineFeature.GENERATE_BIOMES, MediumgasmineFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
