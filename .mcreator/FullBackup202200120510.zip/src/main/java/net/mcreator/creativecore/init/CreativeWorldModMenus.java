
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.creativecore.world.inventory.MsrpmroMenu;
import net.mcreator.creativecore.world.inventory.FgfhffhghkjkkytwqaMenu;
import net.mcreator.creativecore.world.inventory.FdgdfMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CreativeWorldModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<MsrpmroMenu> MSRPMRO = register("msrpmro", (id, inv, extraData) -> new MsrpmroMenu(id, inv, extraData));
	public static final MenuType<FdgdfMenu> FDGDF = register("fdgdf", (id, inv, extraData) -> new FdgdfMenu(id, inv, extraData));
	public static final MenuType<FgfhffhghkjkkytwqaMenu> FGFHFFHGHKJKKYTWQA = register("fgfhffhghkjkkytwqa",
			(id, inv, extraData) -> new FgfhffhghkjkkytwqaMenu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
