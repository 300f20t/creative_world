
package net.mcreator.creativecore.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;

import net.mcreator.creativecore.procedures.BatteryKoghdaPriedmietIzghotovlienpierieplavlienProcedure;
import net.mcreator.creativecore.init.CreativeWorldModTabs;

public class BatteryItem extends Item {
	public BatteryItem() {
		super(new Item.Properties().tab(CreativeWorldModTabs.TAB_CREATIVE_WOR_1D).durability(1001).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.EAT;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Level world, Player entity) {
		super.onCraftedBy(itemstack, world, entity);
		BatteryKoghdaPriedmietIzghotovlienpierieplavlienProcedure.execute(itemstack);
	}
}
