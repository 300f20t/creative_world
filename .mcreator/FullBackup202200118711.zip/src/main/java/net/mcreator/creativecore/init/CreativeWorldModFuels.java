
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

@Mod.EventBusSubscriber
public class CreativeWorldModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == CreativeWorldModItems.THECOREOFMATTER.get())
			event.setBurnTime(1000000000);
		else if (event.getItemStack().getItem() == CreativeWorldModBlocks.GAS.get().asItem())
			event.setBurnTime(128000);
		else if (event.getItemStack().getItem() == CreativeWorldModBlocks.OIL.get().asItem())
			event.setBurnTime(100000);
	}
}
