
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creativecore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.creativecore.item.WirecuttersItem;
import net.mcreator.creativecore.item.WashedcrushedtinoreItem;
import net.mcreator.creativecore.item.WashedcrushedironoreItem;
import net.mcreator.creativecore.item.WashedcrushedcopperoreItem;
import net.mcreator.creativecore.item.TinplateItem;
import net.mcreator.creativecore.item.TinnuggetItem;
import net.mcreator.creativecore.item.TincoverItem;
import net.mcreator.creativecore.item.TinSwordItem;
import net.mcreator.creativecore.item.TinShovelItem;
import net.mcreator.creativecore.item.TinPickaxeItem;
import net.mcreator.creativecore.item.TinIngotItem;
import net.mcreator.creativecore.item.TinHoeItem;
import net.mcreator.creativecore.item.TinAxeItem;
import net.mcreator.creativecore.item.TinArmorItem;
import net.mcreator.creativecore.item.ThecoreoftheformationItem;
import net.mcreator.creativecore.item.ThecoreofmatterItem;
import net.mcreator.creativecore.item.TapItem;
import net.mcreator.creativecore.item.SdfghnItem;
import net.mcreator.creativecore.item.RubberItem;
import net.mcreator.creativecore.item.RawtinItem;
import net.mcreator.creativecore.item.OilItem;
import net.mcreator.creativecore.item.LatexItem;
import net.mcreator.creativecore.item.IronwrenchItem;
import net.mcreator.creativecore.item.IronplateItem;
import net.mcreator.creativecore.item.IronhammerItem;
import net.mcreator.creativecore.item.GasItem;
import net.mcreator.creativecore.item.EnergydetectorItem;
import net.mcreator.creativecore.item.EndlesswatersourceItem;
import net.mcreator.creativecore.item.ElectricjetpackItem;
import net.mcreator.creativecore.item.CrushedtinoreItem;
import net.mcreator.creativecore.item.CrushedironoreItem;
import net.mcreator.creativecore.item.CrushedcopperoreItem;
import net.mcreator.creativecore.item.CreativemodItem;
import net.mcreator.creativecore.item.CreatingcoreItem;
import net.mcreator.creativecore.item.CopperplateItem;
import net.mcreator.creativecore.item.CoppernuggetItem;
import net.mcreator.creativecore.item.CopperSwordItem;
import net.mcreator.creativecore.item.CopperShovelItem;
import net.mcreator.creativecore.item.CopperPickaxeItem;
import net.mcreator.creativecore.item.CopperHoeItem;
import net.mcreator.creativecore.item.CopperAxeItem;
import net.mcreator.creativecore.item.CopperArmorItem;
import net.mcreator.creativecore.item.BronzedustItem;
import net.mcreator.creativecore.item.BedrockbreackerItem;
import net.mcreator.creativecore.item.BatteryItem;
import net.mcreator.creativecore.item.Battery5Item;
import net.mcreator.creativecore.item.Battery4Item;
import net.mcreator.creativecore.item.Battery3Item;
import net.mcreator.creativecore.item.Battery2Item;
import net.mcreator.creativecore.item.Battery1Item;
import net.mcreator.creativecore.item.Alargebucketofwater9Item;
import net.mcreator.creativecore.item.Alargebucketofwater8Item;
import net.mcreator.creativecore.item.Alargebucketofwater7Item;
import net.mcreator.creativecore.item.Alargebucketofwater6Item;
import net.mcreator.creativecore.item.Alargebucketofwater5Item;
import net.mcreator.creativecore.item.Alargebucketofwater4Item;
import net.mcreator.creativecore.item.Alargebucketofwater3Item;
import net.mcreator.creativecore.item.Alargebucketofwater2Item;
import net.mcreator.creativecore.item.Alargebucketofwater1Item;
import net.mcreator.creativecore.item.AlargebucketItem;
import net.mcreator.creativecore.CreativeWorldMod;

public class CreativeWorldModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CreativeWorldMod.MODID);
	public static final RegistryObject<Item> ALARGEBUCKET = REGISTRY.register("alargebucket", () -> new AlargebucketItem());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_1 = REGISTRY.register("alargebucketofwater_1", () -> new Alargebucketofwater1Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_2 = REGISTRY.register("alargebucketofwater_2", () -> new Alargebucketofwater2Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_3 = REGISTRY.register("alargebucketofwater_3", () -> new Alargebucketofwater3Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_4 = REGISTRY.register("alargebucketofwater_4", () -> new Alargebucketofwater4Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_5 = REGISTRY.register("alargebucketofwater_5", () -> new Alargebucketofwater5Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_6 = REGISTRY.register("alargebucketofwater_6", () -> new Alargebucketofwater6Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_7 = REGISTRY.register("alargebucketofwater_7", () -> new Alargebucketofwater7Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_8 = REGISTRY.register("alargebucketofwater_8", () -> new Alargebucketofwater8Item());
	public static final RegistryObject<Item> ALARGEBUCKETOFWATER_9 = REGISTRY.register("alargebucketofwater_9", () -> new Alargebucketofwater9Item());
	public static final RegistryObject<Item> ENDLESSWATERSOURCE = REGISTRY.register("endlesswatersource", () -> new EndlesswatersourceItem());
	public static final RegistryObject<Item> TIN_INGOT = REGISTRY.register("tin_ingot", () -> new TinIngotItem());
	public static final RegistryObject<Item> TINPLATE = REGISTRY.register("tinplate", () -> new TinplateItem());
	public static final RegistryObject<Item> COPPERPLATE = REGISTRY.register("copperplate", () -> new CopperplateItem());
	public static final RegistryObject<Item> IRONPLATE = REGISTRY.register("ironplate", () -> new IronplateItem());
	public static final RegistryObject<Item> TIN_PICKAXE = REGISTRY.register("tin_pickaxe", () -> new TinPickaxeItem());
	public static final RegistryObject<Item> TIN_AXE = REGISTRY.register("tin_axe", () -> new TinAxeItem());
	public static final RegistryObject<Item> TIN_SHOVEL = REGISTRY.register("tin_shovel", () -> new TinShovelItem());
	public static final RegistryObject<Item> TIN_HOE = REGISTRY.register("tin_hoe", () -> new TinHoeItem());
	public static final RegistryObject<Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final RegistryObject<Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final RegistryObject<Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final RegistryObject<Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final RegistryObject<Item> IRONHAMMER = REGISTRY.register("ironhammer", () -> new IronhammerItem());
	public static final RegistryObject<Item> IRONWRENCH = REGISTRY.register("ironwrench", () -> new IronwrenchItem());
	public static final RegistryObject<Item> WIRECUTTERS = REGISTRY.register("wirecutters", () -> new WirecuttersItem());
	public static final RegistryObject<Item> MACHINECASE = block(CreativeWorldModBlocks.MACHINECASE, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> COALGENERATOR = block(CreativeWorldModBlocks.COALGENERATOR, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> CRUSHER = block(CreativeWorldModBlocks.CRUSHER, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> TIN_ORE = block(CreativeWorldModBlocks.TIN_ORE, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> TIN_BLOCK = block(CreativeWorldModBlocks.TIN_BLOCK, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_WOOD = block(CreativeWorldModBlocks.RESIN_WOOD, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_LOG = block(CreativeWorldModBlocks.RESIN_LOG, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RSINLOGWITHRESIN = block(CreativeWorldModBlocks.RSINLOGWITHRESIN,
			CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_PLANKS = block(CreativeWorldModBlocks.RESIN_PLANKS, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_LEAVES = block(CreativeWorldModBlocks.RESIN_LEAVES, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_STAIRS = block(CreativeWorldModBlocks.RESIN_STAIRS, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_SLAB = block(CreativeWorldModBlocks.RESIN_SLAB, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_FENCE = block(CreativeWorldModBlocks.RESIN_FENCE, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RESIN_FENCE_GATE = block(CreativeWorldModBlocks.RESIN_FENCE_GATE,
			CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> TIN_SWORD = REGISTRY.register("tin_sword", () -> new TinSwordItem());
	public static final RegistryObject<Item> TIN_ARMOR_HELMET = REGISTRY.register("tin_armor_helmet", () -> new TinArmorItem.Helmet());
	public static final RegistryObject<Item> TIN_ARMOR_CHESTPLATE = REGISTRY.register("tin_armor_chestplate", () -> new TinArmorItem.Chestplate());
	public static final RegistryObject<Item> TIN_ARMOR_LEGGINGS = REGISTRY.register("tin_armor_leggings", () -> new TinArmorItem.Leggings());
	public static final RegistryObject<Item> TIN_ARMOR_BOOTS = REGISTRY.register("tin_armor_boots", () -> new TinArmorItem.Boots());
	public static final RegistryObject<Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final RegistryObject<Item> COPPER_ARMOR_HELMET = REGISTRY.register("copper_armor_helmet", () -> new CopperArmorItem.Helmet());
	public static final RegistryObject<Item> COPPER_ARMOR_CHESTPLATE = REGISTRY.register("copper_armor_chestplate",
			() -> new CopperArmorItem.Chestplate());
	public static final RegistryObject<Item> COPPER_ARMOR_LEGGINGS = REGISTRY.register("copper_armor_leggings", () -> new CopperArmorItem.Leggings());
	public static final RegistryObject<Item> COPPER_ARMOR_BOOTS = REGISTRY.register("copper_armor_boots", () -> new CopperArmorItem.Boots());
	public static final RegistryObject<Item> THECOREOFTHEFORMATION = REGISTRY.register("thecoreoftheformation",
			() -> new ThecoreoftheformationItem());
	public static final RegistryObject<Item> THECOREOFMATTER = REGISTRY.register("thecoreofmatter", () -> new ThecoreofmatterItem());
	public static final RegistryObject<Item> CREATINGCORE = REGISTRY.register("creatingcore", () -> new CreatingcoreItem());
	public static final RegistryObject<Item> BEDROCKBREACKER = REGISTRY.register("bedrockbreacker", () -> new BedrockbreackerItem());
	public static final RegistryObject<Item> COALGENERATOR_1 = block(CreativeWorldModBlocks.COALGENERATOR_1, null);
	public static final RegistryObject<Item> SOLARPANEL = block(CreativeWorldModBlocks.SOLARPANEL, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> CRUSHEDIRONORE = REGISTRY.register("crushedironore", () -> new CrushedironoreItem());
	public static final RegistryObject<Item> TINWIRE = block(CreativeWorldModBlocks.TINWIRE, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> CRUSHEDCOPPERORE = REGISTRY.register("crushedcopperore", () -> new CrushedcopperoreItem());
	public static final RegistryObject<Item> CRUSHEDTINORE = REGISTRY.register("crushedtinore", () -> new CrushedtinoreItem());
	public static final RegistryObject<Item> TINNUGGET = REGISTRY.register("tinnugget", () -> new TinnuggetItem());
	public static final RegistryObject<Item> COPPERNUGGET = REGISTRY.register("coppernugget", () -> new CoppernuggetItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDIRONORE = REGISTRY.register("washedcrushedironore", () -> new WashedcrushedironoreItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDCOPPERORE = REGISTRY.register("washedcrushedcopperore",
			() -> new WashedcrushedcopperoreItem());
	public static final RegistryObject<Item> WASHEDCRUSHEDTINORE = REGISTRY.register("washedcrushedtinore", () -> new WashedcrushedtinoreItem());
	public static final RegistryObject<Item> CREATIVEMOD = REGISTRY.register("creativemod", () -> new CreativemodItem());
	public static final RegistryObject<Item> LATEX = REGISTRY.register("latex", () -> new LatexItem());
	public static final RegistryObject<Item> TAP = REGISTRY.register("tap", () -> new TapItem());
	public static final RegistryObject<Item> RUBBER = REGISTRY.register("rubber", () -> new RubberItem());
	public static final RegistryObject<Item> TINCOVER = REGISTRY.register("tincover", () -> new TincoverItem());
	public static final RegistryObject<Item> BATTERY = REGISTRY.register("battery", () -> new BatteryItem());
	public static final RegistryObject<Item> TINWIREWITHRUBBER = block(CreativeWorldModBlocks.TINWIREWITHRUBBER,
			CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> OIL_BUCKET = REGISTRY.register("oil_bucket", () -> new OilItem());
	public static final RegistryObject<Item> GAS_BUCKET = REGISTRY.register("gas_bucket", () -> new GasItem());
	public static final RegistryObject<Item> BATTERY_1 = REGISTRY.register("battery_1", () -> new Battery1Item());
	public static final RegistryObject<Item> BATTERY_2 = REGISTRY.register("battery_2", () -> new Battery2Item());
	public static final RegistryObject<Item> BATTERY_3 = REGISTRY.register("battery_3", () -> new Battery3Item());
	public static final RegistryObject<Item> BATTERY_4 = REGISTRY.register("battery_4", () -> new Battery4Item());
	public static final RegistryObject<Item> BATTERY_5 = REGISTRY.register("battery_5", () -> new Battery5Item());
	public static final RegistryObject<Item> TINWIREWITHRUBBER_2 = block(CreativeWorldModBlocks.TINWIREWITHRUBBER_2,
			CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> RAWTIN = REGISTRY.register("rawtin", () -> new RawtinItem());
	public static final RegistryObject<Item> BRONZEDUST = REGISTRY.register("bronzedust", () -> new BronzedustItem());
	public static final RegistryObject<Item> ENERGYDETECTOR = REGISTRY.register("energydetector", () -> new EnergydetectorItem());
	public static final RegistryObject<Item> FAN = block(CreativeWorldModBlocks.FAN, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> BATTERYBLOCK = block(CreativeWorldModBlocks.BATTERYBLOCK, CreativeWorldModTabs.TAB_CREATIVE_WOR_1D);
	public static final RegistryObject<Item> ELECTRICJETPACK_CHESTPLATE = REGISTRY.register("electricjetpack_chestplate",
			() -> new ElectricjetpackItem.Chestplate());
	public static final RegistryObject<Item> SDFGHN = REGISTRY.register("sdfghn", () -> new SdfghnItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
